//! 👁 GLITCH BOX — a dealer-positioning map reader (Rust)
//! =====================================================
//! Reads one GEX/VEX book (strikes × expiries of gamma and vanna) the way the doctrine reads it, and prints the box:
//!
//!   1. The FRONT map (the nearest expiry): King, ceiling, floor, the gatekeepers between the King and each bound,
//!      the air pockets between spot and the next structure, the counter-sign landmarks. Ceiling and floor are
//!      SIGN-AGNOSTIC: the largest |γ| cell on that side of spot (absolute value + location decide, not sign).
//!   2. The FULL map (every expiry): King, ceiling and floor as the largest SINGLE CELL — never a sum across expiries.
//!   3. Node roles on both maps: King = largest |γ| · Pika = the next largest positive cells (yellow +γ) · Barney = the
//!      largest negative cells (purple −γ) · Gatekeeper = any other cell ≥ ¼ of the King.
//!   4. Structures: rugpull / reverse rugpull, double-stacked ceiling / floor, air pockets, gatekeeper state, King peak/pit.
//!   5. Glitch's OWN plan: a deflection entry at the floor (long) or the ceiling (short), the stop one node beyond plus
//!      an overshoot margin, the target = the gatekeeper on the way to the King, else the King, else the opposite bound.
//!   6. Two theses (upside / downside), written from named nodes in price order, with no probability words.
//!   7. Wear (needs daily bars): taps in the last 10 sessions, the session range, fresh / in-play / delivered levels,
//!      and the REACH tag (the odds a bound is TOUCHED next session — never HELD).
//!   8. Regime + Trinity (SPX / SPY / QQQ bias from each index's full-map King) and the JUDGE: the doctrine's five
//!      filters run on an outside plan. A checklist, never a probability: in training the verdict was INVERTED.
//!   9. Every node, structure and judge line cites measured base rates from `base_rates.json` (1,688 rows, n ≥ 100,
//!      value · n · 95% CI · a discovery and a holdout value). Base rates, never levers.
//!
//! DISPLAY ONLY. Nothing here picks a side, sizes a position or vetoes a trade.
//!
//! Plug points (yours to wire): `load_book(symbol)` — the GEX/VEX book as plain arrays; `load_daily_bars(symbol, end)` —
//! daily high/low bars, oldest first (optional: without them wear, reach and the regime read as unread).
//!
//! Run:  glitch_box demo [--json] [--verbose]          a built-in synthetic book, no plugs needed
//!       glitch_box show SYM [--plan long|short ENTRY TARGET STOP MODE] [--json] [--verbose]
//!       glitch_box board SYM… [--json]                  every ticker's box; Trinity reads SPY / QQQ / SPXW / VIX from the list
//!
//! Build: `cargo build --release` (deps: serde, serde_json). Rust 1.70+.
#![allow(clippy::too_many_arguments, clippy::type_complexity, dead_code)]
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::OnceLock;

// ═══════════════════════════════════════════════ 1. JS-faithful numerics ═══════════════════════════════════════════
// The box was first written in JavaScript; these helpers reproduce its rounding so every printed digit matches.

/// JavaScript `Math.round`: half-way cases round toward +∞ (−2.5 → −2).
pub fn js_round(x: f64) -> f64 {
    if !x.is_finite() { return x; }
    let r = x.round();
    if x - x.trunc() == -0.5 { r + 1.0 } else { r }
}

/// JavaScript `toFixed(d)`: correctly rounded on the exact binary value, exact ties away from zero.
pub fn js_to_fixed(x: f64, d: usize) -> String {
    if x.is_nan() { return "NaN".into(); }
    if x.is_infinite() { return if x > 0.0 { "Infinity".into() } else { "-Infinity".into() }; }
    let a = x.abs();
    let long = format!("{:.*}", d + 25, a);
    let frac = long.split_once('.').map(|(_, f)| f).unwrap_or("");
    let tail = &frac[d.min(frac.len())..];
    let is_tie = tail.starts_with('5') && tail[1..].bytes().all(|b| b == b'0');
    let body = if is_tie {
        let p = 10f64.powi(d as i32);
        let n = (a * p).floor() + 1.0;
        format!("{:.*}", d, n / p)
    } else {
        format!("{:.*}", d, a)
    };
    if x < 0.0 { format!("-{}", body) } else { body }
}

/// `+x.toFixed(d)` — the rounded value as a number.
pub fn fixed(x: f64, d: usize) -> f64 { js_to_fixed(x, d).parse().unwrap_or(x) }

/// A number as JavaScript prints it inside a string (`String(x)`).
pub fn js_num(x: f64) -> String {
    if x.is_nan() { return "NaN".into(); }
    if x.is_infinite() { return if x > 0.0 { "Infinity".into() } else { "-Infinity".into() }; }
    if x == 0.0 { return "0".into(); }
    let a = x.abs();
    if a >= 1e21 || a < 1e-7 {
        let e = format!("{:e}", x);
        return match e.split_once('e') { Some((m, ex)) if !ex.starts_with('-') => format!("{}e+{}", m, ex), _ => e };
    }
    if x == x.trunc() { format!("{}", x as i64) } else { format!("{}", x) }
}

/// An integer with thousands separators (`toLocaleString('en-US')`).
pub fn thousands(x: f64) -> String {
    let neg = x < 0.0;
    let s = format!("{}", js_round(x.abs()) as i64);
    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() { if i > 0 && (s.len() - i) % 3 == 0 { out.push(','); } out.push(ch); }
    if neg { format!("-{}", out) } else { out }
}

/// Price formatter: index products print whole points, everything else two decimals.
pub fn px(sym: &str, v: f64) -> String {
    if sym.contains("SPX") || sym.contains("NDX") || sym.contains("RUT") || sym.contains("VIX") { js_to_fixed(v, 0) } else { js_to_fixed(v, 2) }
}
fn pxo(sym: &str, v: Option<f64>) -> String { v.map(|x| px(sym, x)).unwrap_or_else(|| "—".into()) }

/// Dollar-notional formatter: $1.23B · $4.5M · $678K.
pub fn fmt_k(v: f64) -> String {
    let a = v.abs();
    let s = if a >= 1e9 { js_to_fixed(a / 1e9, 2) + "B" } else if a >= 1e6 { js_to_fixed(a / 1e6, 1) + "M" } else { js_to_fixed(a / 1e3, 0) + "K" };
    format!("{}{}", if v < 0.0 { "-$" } else { "$" }, s)
}
fn fmt_ko(v: Option<f64>) -> String { v.map(fmt_k).unwrap_or_else(|| "—".into()) }

fn abs_gt(a: f64, b: f64) -> bool { a.abs() > b.abs() }

// ═══════════════════════════════════════════════ 2. Constants ═══════════════════════════════════════════════════════

/// Significance = ¼ of the King. A magnitude ratio, never a price radius.
pub const SIG: f64 = 0.25;
/// Trinity: a full-map King within 0.1% of spot reads NEUTRAL.
pub const NEUTRAL: f64 = 0.001;
/// A level touched this session with price already 0.3% away is DELIVERED.
pub const DELIVER: f64 = 0.003;
/// Judge filter 5: the target and stop nodes must each carry at least this |γ| notional.
pub const MAG: f64 = 1000.0;
/// Overshoot margin past a node: a fixed point value for the four index products, else 0.07% of spot.
pub const OVERSHOOT_PCT: f64 = 0.0007;
pub fn overshoot_pts(sym: &str) -> Option<f64> { match sym { "SPY" | "QQQ" => Some(0.5), "SPXW" | "SPX" => Some(4.0), _ => None } }
/// The classifier's gatekeeper cut (¼ of the King).
pub const GK_PCT: f64 = 0.25;

/// REACH tags: a bound's odds of being TOUCHED next session, by |bound| ÷ |front King| and the last 5 sessions' taps.
/// Holdout Jan-2026, 20,764 bound rows. A bound is touched MORE than a same-distance strike and HELD LESS once touched.
pub const REACH_RATIO_CUT: f64 = 0.6865;
pub struct ReachSpec { pub tag: &'static str, pub rate: f64, pub n: f64, pub ci: [f64; 2], pub rule: &'static str }
pub const REACH_TAGS: [ReachSpec; 4] = [
    ReachSpec { tag: "THIN", rate: 17.9, n: 1715.0, ci: [16.2, 19.8], rule: "untested in 5 sessions and under 0.69× the King" },
    ReachSpec { tag: "FRESH-BIG", rate: 33.7, n: 205.0, ci: [27.5, 40.4], rule: "untested in 5 sessions, ≥ 0.69× the King" },
    ReachSpec { tag: "TESTED", rate: 46.6, n: 1560.0, ci: [44.1, 49.1], rule: "touched in 1–2 of the last 5 sessions (any size)" },
    ReachSpec { tag: "WORN", rate: 59.1, n: 809.0, ci: [55.7, 62.4], rule: "touched in 3+ of the last 5 sessions (any size)" },
];
fn reach_spec(tag: &str) -> &'static ReachSpec { REACH_TAGS.iter().find(|r| r.tag == tag).unwrap() }

/// Calibration figures quoted in the box's wording. [n fills, $ per $1k a fill, TP1 %] unless noted;
/// per-symbol sign tests; discovery Nov-2025 / holdout Jan-2026.
pub mod cal {
    pub const RETEST: (f64, f64, f64, f64) = (4222.0, 38.0, 36.0, 0.15); // n, hold after 1–2 tests %, hold after 3+ %, p
    pub const JUDGE_DTE3: [[f64; 3]; 3] = [[2151.0, 35.9, 16.3], [88.0, 29.4, 3.4], [73.0, 1.1, 2.7]]; // NO PLAY · VALID · A+ — INVERTED
    pub const JUDGE_SWING: [[f64; 3]; 3] = [[2134.0, 52.8, 18.4], [86.0, 35.5, 4.7], [69.0, -2.8, 2.9]];
    pub const DS_CEIL: (f64, f64, f64, f64, f64) = (389.0, 81.3, 104.0, 74.0, 0.029); // n, $/1k, wins, losses, p
    pub const RUGPULL: [f64; 3] = [473.0, 53.4, 64.5]; // boards, direction hit %, the board's own coin %
    pub const REVERSE_RUGPULL: [f64; 3] = [455.0, 45.1, 63.5];
    pub const TRINITY: (f64, f64, f64) = (91.0, 116.0, 0.095); // wins, losses, p — opposite sign to the doctrine
    pub const GREW_KING: [f64; 4] = [340.0, 47.7, 34.6, 4.3e-5]; // n grew, touched next session % grew, % flat, p
}

pub const JUDGE_TIP: &str = "This checklist counts which of the doctrine's five conditions the plan meets right now. It is NOT a win probability. On the training corpus the verdict is INVERTED: NO PLAY boards paid more and hit TP1 more often than A+ PLAYS in both arms (0-3DTE: NO PLAY $35.9 per $1k a fill, TP1 16% against A+ $1.1, 3%; swing $52.8, 18% against -$2.8, 3%). Read it as how clean the setup is on paper, never as how likely it is to work.";
pub const FOOT: &str = "trained on 6,801 boards · Glitch's deflection plan agreed with the better outcome on more SYMBOLS than the engine's plan (191 vs 110, p < 0.0001) while the engine's plan captured more money in aggregate ($50.5 vs $43.4 per $1k a fill), both tail-carried (83-86% of either plan's money in its top decile) — never one half without the other · display only";
pub const TRIN_TIP: &str = "The doctrine's SPX / SPY / QQQ check off this board's own index cards: bias = which side of spot the FULL-map King sits (within 0.1% = NEUTRAL). On the training corpus a strict 3/3 was reached on 0 of 6,801 boards (SPXW's King sat within 0.1% of spot on every session it was served), so the regime uses the 2-of-3 SPY = QQQ proxy; and aligned boards did NOT pay more than divergent ones (per-symbol 91/116, p 0.095, the opposite sign to the doctrine). A fact about the board, never a conviction dial.";
pub const HEAD_TIP: &str = "👁 GLITCH BOX — the doctrine read of THIS board, built on the front expiry of the untrimmed grid. Node roles: King = largest |γ| cell, Pika = the next largest positive, Barney = the largest negative, Gatekeeper ≥ ¼ of the King. Every chip is one measured base rate (value of n; the JSON carries the key, the 95% CI and the Nov-2025 / Jan-2026 values) — base rates from 6,801 boards and 1,322 intraday pulls, never levers. Every refuted doctrine claim is labelled doctrine-only. Display only.";

// ═══════════════════════════════════════════════ 3. Base rates ═════════════════════════════════════════════════════

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BaseRate {
    pub v: f64,
    pub n: f64,
    #[serde(default)] pub lo: Option<f64>,
    #[serde(default)] pub hi: Option<f64>,
    /// discovery block (Nov-2025)
    #[serde(default)] pub disc: Option<f64>,
    /// holdout block (Jan-2026)
    #[serde(default)] pub hold: Option<f64>,
    /// unit: rate · ratio · pct · min
    pub u: String,
    /// next_session (6,801 boards) or intraday (12 names, 1,322 pulls)
    pub src: String,
    #[serde(default)] pub note: Option<String>,
}

static BASE_RATES_JSON: &str = include_str!("base_rates.json");
static BASE_RATES: OnceLock<HashMap<String, BaseRate>> = OnceLock::new();
pub fn base_rates() -> &'static HashMap<String, BaseRate> {
    BASE_RATES.get_or_init(|| serde_json::from_str(BASE_RATES_JSON).expect("base_rates.json"))
}
/// One measured base rate, or None (n < 100 never prints).
pub fn base_rate(key: &str) -> Option<&'static BaseRate> { base_rates().get(key).filter(|r| r.n >= 100.0) }

pub fn dist_bucket(k: f64, spot: f64) -> &'static str {
    let d = (k - spot).abs() / spot * 100.0;
    if d < 0.5 { "0-0.5" } else if d < 1.0 { "0.5-1" } else if d < 2.0 { "1-2" } else if d < 4.0 { "2-4" } else if d < 8.0 { "4-8" } else { "8plus" }
}
pub fn node_key(measure: &str, map: &str, role: &str, v: f64, k: f64, spot: f64) -> String {
    format!("glitch.node.{}.map={}.role={}.sign={}.side={}.dist={}", measure, map, role, if v < 0.0 { "neg" } else { "pos" }, if k > spot { "above" } else { "below" }, dist_bucket(k, spot))
}

/// One base rate as a chip: `label value of n`. Empty when the table has no such row.
pub fn cite(key: &str, label: &str) -> String {
    let Some(r) = base_rate(key) else { return String::new() };
    let val = if r.u == "rate" { format!("{}%", js_num(js_round(r.v * 100.0))) } else { js_num(fixed(r.v, 2)) };
    if label.is_empty() { format!(" [{} of {}]", val, thousands(r.n)) } else { format!(" [{} {} of {}]", label, val, thousands(r.n)) }
}

// ═══════════════════════════════════════════════ 4. The book ════════════════════════════════════════════════════════

/// One GEX/VEX book: `gamma[i][j]` and `vanna[i][j]` are the dealer exposures at `strikes[i]` for `expiries[j]`
/// (nearest expiry first). Pass the WHOLE book — every strike and expiry you have; the box never trims.
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Book {
    pub symbol: String,
    pub spot: f64,
    pub expiries: Vec<String>,
    pub strikes: Vec<f64>,
    pub gamma: Vec<Vec<f64>>,
    pub vanna: Vec<Vec<f64>>,
}

/// One daily bar: session date (YYYY-MM-DD), high, low.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Bar { pub d: String, pub h: f64, pub l: f64 }

/// ▶ PLUG POINT 1 — return the GEX/VEX book for `symbol` here (your data source; nothing else in this file fetches).
pub fn load_book(_symbol: &str) -> Result<Book, String> {
    Err("load_book is not wired: plug your GEX/VEX book in here".into())
}
/// ▶ PLUG POINT 2 — daily bars for `symbol` up to `end` (YYYY-MM-DD), oldest first; ~65 calendar days is plenty.
/// Return an empty Vec to run without wear (taps, delivery, range, reach and the regime then read as unread).
pub fn load_daily_bars(_symbol: &str, _end: &str) -> Vec<Bar> { Vec::new() }

#[derive(Clone, Debug)]
pub struct Row { pub strike: f64, pub g_near: f64, pub gx: Vec<f64>, pub vx: Vec<f64> }

fn num0(x: f64) -> f64 { if x.is_nan() { 0.0 } else { x } }

/// The untrimmed grid as rows: non-finite strikes and all-zero rows dropped, sorted by strike.
pub fn rows_of(b: &Book) -> Vec<Row> {
    let mut rows = Vec::new();
    for (i, &k) in b.strikes.iter().enumerate() {
        if !k.is_finite() { continue; }
        let ga: Vec<f64> = match b.gamma.get(i) { Some(v) if !v.is_empty() => v.iter().map(|&x| num0(x)).collect(), _ => vec![0.0] };
        let va: Vec<f64> = match b.vanna.get(i) { Some(v) if !v.is_empty() => v.iter().map(|&x| num0(x)).collect(), _ => vec![0.0] };
        if !ga.iter().any(|&x| x != 0.0) && !va.iter().any(|&x| x != 0.0) { continue; }
        rows.push(Row { strike: k, g_near: ga[0], gx: ga, vx: va });
    }
    rows.sort_by(|a, b| a.strike.partial_cmp(&b.strike).unwrap_or(std::cmp::Ordering::Equal));
    rows
}

// ═══════════════════════════════════════════════ 5. The front map ═══════════════════════════════════════════════════

#[derive(Clone, Copy, Debug)]
struct Gc { k: f64, g: f64 }

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Gate {
    /// no-bound · pinned (the King IS the bound) · adjacent · open (no node ≥ ¼ King between) · node (a real gatekeeper)
    pub state: String,
    #[serde(skip_serializing_if = "Option::is_none")] pub k: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")] pub v: Option<f64>,
    /// false = the gatekeeper sits on the other side of spot from its bound (behind the King)
    #[serde(rename = "inPath", skip_serializing_if = "Option::is_none")] pub in_path: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")] pub n: Option<usize>,
}
impl Gate { fn st(s: &str) -> Gate { Gate { state: s.into(), k: None, v: None, in_path: None, n: None } } }

#[derive(Clone, Debug)]
pub struct Pocket { pub state: String, pub lo: Option<f64>, pub hi: Option<f64>, pub to: Option<f64>, pub net: Option<f64>, pub rungs: Option<usize>, pub neg: bool }

#[derive(Clone, Copy, Debug)]
pub struct Bound { pub k: f64, pub v: f64, pub rung: i64 }

/// The front-expiry read: King · ceiling · floor (sign-agnostic, largest |γ| on that side) · counter-sign landmarks ·
/// gatekeepers · air pockets · the grid step.
#[derive(Clone, Debug)]
pub struct FrontMap {
    pub spot: f64,
    pub step: Option<f64>,
    pub king: Bound,
    pub pit: bool,
    pub ceiling: Option<Bound>,
    pub floor: Option<Bound>,
    pub cn_up: Option<f64>,
    pub cn_dn: Option<f64>,
    pub gk_c: Gate,
    pub gk_f: Gate,
    pub pk_up: Pocket,
    pub pk_dn: Pocket,
}

fn biggest(xs: &[Gc]) -> Option<Gc> { let mut b: Option<Gc> = None; for &r in xs { match b { None => b = Some(r), Some(c) => if abs_gt(r.g, c.g) { b = Some(r) } } } b }

pub fn front_map(rows: &[Row], spot: f64) -> Option<FrontMap> {
    if rows.is_empty() || !(spot > 0.0) { return None; }
    let mut l: Vec<f64> = rows.iter().map(|r| r.strike).collect();
    l.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let steps = |k: f64| -> i64 {
        if k > spot { l.iter().filter(|&&x| x > spot && x <= k).count() as i64 } else if k < spot { -(l.iter().filter(|&&x| x >= k && x < spot).count() as i64) } else { 0 }
    };
    let mut col: Vec<Gc> = rows.iter().map(|r| Gc { k: r.strike, g: if r.gx.is_empty() { r.g_near } else { r.gx[0] } }).collect();
    col.sort_by(|a, b| a.k.partial_cmp(&b.k).unwrap());
    let king = biggest(&col).unwrap();
    let kmag = if king.g.abs() != 0.0 { king.g.abs() } else { 1.0 };
    let sig = SIG * kmag;
    let half = |dir: i32| -> Vec<Gc> { col.iter().copied().filter(|r| if dir > 0 { r.k > spot } else { r.k < spot }).collect() };
    let ceiling = biggest(&half(1));
    let floor = biggest(&half(-1));
    let counter = |dir: i32, bound: Option<Gc>| -> Option<Gc> {
        let b = bound?;
        let xs: Vec<Gc> = half(dir).into_iter().filter(|r| r.g != 0.0 && (r.g > 0.0) != (b.g > 0.0) && r.g.abs() >= sig).collect();
        biggest(&xs)
    };
    let gate = |bound: Option<Gc>| -> Gate {
        let Some(b) = bound else { return Gate::st("no-bound") };
        if b.k == king.k { return Gate::st("pinned"); }
        let (lo, hi) = (king.k.min(b.k), king.k.max(b.k));
        let mid: Vec<Gc> = col.iter().copied().filter(|r| r.k > lo && r.k < hi).collect();
        if mid.is_empty() { return Gate::st("adjacent"); }
        let big: Vec<Gc> = mid.iter().copied().filter(|r| r.g.abs() >= sig).collect();
        if big.is_empty() { return Gate { n: Some(mid.len()), ..Gate::st("open") }; }
        let n = biggest(&big).unwrap();
        Gate { state: "node".into(), k: Some(n.k), v: Some(n.g), in_path: Some((n.k > spot) == (b.k > spot)), n: None }
    };
    let cn_up = counter(1, ceiling);
    let cn_dn = counter(-1, floor);
    let gk_c = gate(ceiling);
    let gk_f = gate(floor);
    let mut strct: Vec<f64> = vec![king.k];
    for x in [ceiling, floor, cn_up, cn_dn].iter().flatten() { strct.push(x.k); }
    if gk_c.state == "node" { strct.push(gk_c.k.unwrap()); }
    if gk_f.state == "node" { strct.push(gk_f.k.unwrap()); }
    let pocket = |dir: i32| -> Pocket {
        let nx: Vec<f64> = strct.iter().copied().filter(|&k| if dir > 0 { k > spot } else { k < spot }).collect();
        let none = |s: &str, to: Option<f64>| Pocket { state: s.into(), lo: None, hi: None, to, net: None, rungs: None, neg: false };
        if nx.is_empty() { return none("no-structure", None); }
        let mut to = nx[0];
        for &k in &nx[1..] { if (k - spot).abs() < (to - spot).abs() { to = k; } }
        let (lo, hi) = (spot.min(to), spot.max(to));
        let seg: Vec<Gc> = col.iter().copied().filter(|r| r.k > lo && r.k < hi).collect();
        if seg.is_empty() { return none("adjacent", Some(to)); }
        if seg.iter().any(|r| r.g.abs() >= sig) { return none("obstructed", Some(to)); }
        let mut net = 0.0; for r in &seg { net += r.g; }
        Pocket { state: "pocket".into(), lo: Some(seg[0].k), hi: Some(seg[seg.len() - 1].k), to: Some(to), net: Some(net), rungs: Some(seg.len()), neg: net < 0.0 }
    };
    let mut gaps: Vec<f64> = Vec::new();
    for i in 1..l.len() { let d = l[i] - l[i - 1]; if d > 0.0 { gaps.push(d); } }
    gaps.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let bnd = |c: Option<Gc>| c.map(|c| Bound { k: c.k, v: c.g, rung: steps(c.k) });
    Some(FrontMap {
        spot, step: if gaps.is_empty() { None } else { Some(gaps[gaps.len() / 2]) },
        king: Bound { k: king.k, v: king.g, rung: steps(king.k) }, pit: king.g < 0.0,
        ceiling: bnd(ceiling), floor: bnd(floor), cn_up: cn_up.map(|c| c.k), cn_dn: cn_dn.map(|c| c.k),
        gk_c, gk_f, pk_up: pocket(1), pk_dn: pocket(-1),
    })
}

// ═══════════════════════════════════════════════ 6. Node roles & the full map ═══════════════════════════════════════

#[derive(Clone, Copy, Debug)]
struct Cl { k: f64, e: usize, v: f64 }

/// Role classifier, cell for cell: King · up to 3 Pikas · up to 3 Barneys · up to 3 Gatekeepers (≥ ¼ King).
/// Returns (cell, role) in assignment order.
fn classify(cells: &[Cl]) -> Vec<(Cl, &'static str)> {
    let l: Vec<Cl> = cells.iter().copied().filter(|c| c.v.is_finite() && c.v != 0.0).collect();
    if l.is_empty() { return Vec::new(); }
    let mut ki = 0; for (i, c) in l.iter().enumerate() { if abs_gt(c.v, l[ki].v) { ki = i; } }
    let kk = l[ki].v.abs();
    let mut used = vec![false; l.len()]; used[ki] = true;
    let mut out = vec![(l[ki], "king")];
    let take = |filt: &dyn Fn(&Cl) -> bool, cmp: &dyn Fn(&Cl, &Cl) -> std::cmp::Ordering, role: &'static str, used: &mut Vec<bool>, out: &mut Vec<(Cl, &'static str)>| {
        let mut idx: Vec<usize> = (0..l.len()).filter(|&i| !used[i] && filt(&l[i])).collect();
        idx.sort_by(|&a, &b| cmp(&l[a], &l[b]));
        for &i in idx.iter().take(3) { used[i] = true; out.push((l[i], role)); }
    };
    take(&|c| c.v > 0.0, &|a, b| b.v.partial_cmp(&a.v).unwrap(), "pika", &mut used, &mut out);
    take(&|c| c.v < 0.0, &|a, b| a.v.partial_cmp(&b.v).unwrap(), "barney", &mut used, &mut out);
    take(&|c| c.v.abs() >= GK_PCT * kk, &|a, b| b.v.abs().partial_cmp(&a.v.abs()).unwrap(), "gatekeeper", &mut used, &mut out);
    out
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Node { pub k: f64, pub e: usize, pub v: f64, pub r: String }

fn role_of(tax: &[(Cl, &'static str)]) -> Vec<Node> {
    let mut v: Vec<(Cl, &'static str)> = tax.to_vec();
    v.sort_by(|a, b| b.0.v.abs().partial_cmp(&a.0.v.abs()).unwrap());
    v.into_iter().take(6).map(|(c, r)| Node { k: c.k, e: c.e, v: js_round(c.v), r: r.into() }).collect()
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct FullCell { pub k: f64, pub e: String, pub g: f64 }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct VannaCell { pub k: f64, pub e: String, pub v: f64 }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct T2 { #[serde(rename = "L")] pub l: Option<VannaCell>, #[serde(rename = "S")] pub s: Option<VannaCell> }

struct FullMapRead { king: Option<FullCell>, ceil: Option<FullCell>, floor: Option<FullCell>, t2: T2 }

/// The FULL-map read: King / floor / ceiling as the largest single CELL across every expiry (no summing),
/// and T2 = the largest |vanna| cell beyond the ceiling (long) / floor (short).
fn full_map(rows: &[Row], exps: &[String], spot: f64) -> Option<FullMapRead> {
    struct C { k: f64, e: String, g: f64, v: f64 }
    let mut cells: Vec<C> = Vec::new();
    for r in rows { for (j, e) in exps.iter().enumerate() {
        let g = num0(*r.gx.get(j).unwrap_or(&0.0)); let v = num0(*r.vx.get(j).unwrap_or(&0.0));
        if g != 0.0 || v != 0.0 { cells.push(C { k: r.strike, e: e.clone(), g, v }); }
    } }
    if cells.is_empty() { return None; }
    fn top<'a>(it: impl Iterator<Item = &'a C>, f: impl Fn(&C) -> f64) -> Option<&'a C> { let mut b: Option<&C> = None; for c in it { if b.map_or(true, |x| f(c) > f(x)) { b = Some(c); } } b }
    let king = top(cells.iter(), |c| c.g.abs());
    let ceil = top(cells.iter().filter(|c| c.k > spot), |c| c.g.abs());
    let floor = top(cells.iter().filter(|c| c.k < spot), |c| c.g.abs());
    let t2l = ceil.and_then(|cc| top(cells.iter().filter(|c| c.k > cc.k), |c| c.v.abs()));
    let t2s = floor.and_then(|ff| top(cells.iter().filter(|c| c.k < ff.k), |c| c.v.abs()));
    let g = |c: Option<&C>| c.map(|c| FullCell { k: c.k, e: c.e.clone(), g: c.g });
    let v = |c: Option<&C>| c.filter(|c| c.v != 0.0).map(|c| VannaCell { k: c.k, e: c.e.clone(), v: c.v });
    Some(FullMapRead { king: g(king), ceil: g(ceil), floor: g(floor), t2: T2 { l: v(t2l), s: v(t2s) } })
}

// ═══════════════════════════════════════════════ 7. The Glitch read ═════════════════════════════════════════════════

/// An outside plan for the judge (entry = `ote`, first target = `tp_near`, stop = `invalidation`, its R:R, its mode).
/// Every field is optional; the judge needs entry, target and stop.
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct Plan {
    pub up: Option<bool>,
    pub ote: Option<f64>,
    #[serde(rename = "tpNear")] pub tp_near: Option<f64>,
    pub invalidation: Option<f64>,
    #[serde(rename = "rrNear")] pub rr_near: Option<f64>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Cell { pub k: f64, pub v: f64, pub rung: i64 }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct PocketOut { pub state: String, pub to: Option<f64>, pub neg: bool, pub rungs: Option<usize> }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Front {
    pub king: Cell, pub pit: bool, pub ceiling: Option<Cell>, pub floor: Option<Cell>,
    #[serde(rename = "gkC")] pub gk_c: Gate, #[serde(rename = "gkF")] pub gk_f: Gate,
    #[serde(rename = "pkUp")] pub pk_up: PocketOut, #[serde(rename = "pkDn")] pub pk_dn: PocketOut,
    #[serde(rename = "cnUp")] pub cn_up: Option<f64>, #[serde(rename = "cnDn")] pub cn_dn: Option<f64>,
    pub nodes: Vec<Node>,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Full { pub king: Option<FullCell>, pub ceil: Option<FullCell>, pub floor: Option<FullCell>, pub t2: T2, pub nodes: Vec<Node> }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct DoubleStack { pub n1: f64, pub n2: f64, pub clean: bool }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Patterns {
    pub rugpull: bool, #[serde(rename = "reverseRugpull")] pub reverse_rugpull: bool,
    #[serde(rename = "pocketUp")] pub pocket_up: bool, #[serde(rename = "pocketDn")] pub pocket_dn: bool,
    #[serde(rename = "dsCeil")] pub ds_ceil: bool, #[serde(rename = "dsFloor")] pub ds_floor: bool,
    #[serde(rename = "dsA")] pub ds_a: Option<DoubleStack>, #[serde(rename = "dsB")] pub ds_b: Option<DoubleStack>,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct PlanMag { pub tp1: Option<f64>, pub inv: Option<f64> }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct GPlan { pub up: bool, pub entry: f64, pub stop: f64, pub target: f64, pub rr: f64, pub osh: f64 }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Plans { #[serde(rename = "L")] pub l: Option<GPlan>, #[serde(rename = "S")] pub s: Option<GPlan> }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Thesis { pub up: String, pub dn: String }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Taps { pub floor: Option<usize>, pub ceiling: Option<usize>, pub tp1: Option<usize>, pub inv: Option<usize> }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Delivered { pub floor: Option<String>, pub ceiling: Option<String>, pub ote: Option<String> }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Wear { pub session: String, pub range: Option<f64>, pub taps: Taps, pub delivered: Delivered }

/// The whole read of one board.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Glitch {
    pub v: u32,
    pub sig: f64,
    pub spot: f64,
    #[serde(rename = "nExps")] pub n_exps: usize,
    #[serde(rename = "frontExp")] pub front_exp: Option<String>,
    pub front: Front,
    pub full: Option<Full>,
    pub patterns: Patterns,
    #[serde(rename = "planMag")] pub plan_mag: Option<PlanMag>,
    pub plan: Plans,
    pub thesis: Thesis,
    pub wear: Option<Wear>,
}

pub fn overshoot(sym: &str, spot: f64) -> f64 { overshoot_pts(sym).unwrap_or(OVERSHOOT_PCT * spot) }

/// Two nearest significant +γ nodes on that side; clean = no significant −γ node between spot and the second.
fn double_stack(ladder: &[Gc], spot: f64, sig: f64, above: bool) -> Option<DoubleStack> {
    let mut pts: Vec<Gc> = ladder.iter().copied().filter(|c| if above { c.k > spot } else { c.k < spot }).collect();
    pts.sort_by(|a, b| (a.k - spot).abs().partial_cmp(&(b.k - spot).abs()).unwrap());
    let pos: Vec<Gc> = pts.iter().copied().filter(|c| c.g >= sig).collect();
    if pos.len() < 2 { return None; }
    let (n1, n2) = (pos[0], pos[1]);
    let (lo, hi) = (spot.min(n2.k), spot.max(n2.k));
    let clean = !pts.iter().any(|c| c.g <= -sig && c.k > lo && c.k < hi);
    Some(DoubleStack { n1: n1.k, n2: n2.k, clean })
}

/// Glitch's own plan: deflection entry at the floor (long) / ceiling (short); stop one node beyond plus the overshoot;
/// target = the gatekeeper on the way to the King, else the King, else the opposite bound.
pub fn glitch_plan(sym: &str, spot: f64, m: &FrontMap, up: bool) -> Option<GPlan> {
    let osh = overshoot(sym, spot);
    let step = match m.step { Some(s) if s != 0.0 => s, _ => spot * 0.01 };
    let king = &m.king;
    let (entry, stop, target);
    if up {
        let floor = m.floor?;
        entry = floor.k;
        stop = (match m.cn_dn { Some(k) => k, None => entry - step }) - osh;
        target = if king.k > spot { if m.gk_c.state == "node" { m.gk_c.k.unwrap() } else { king.k } }
            else if let Some(c) = m.ceiling { c.k } else if spot > entry { entry + 2.0 * (spot - entry) } else { spot + osh };
    } else {
        let ceil = m.ceiling?;
        entry = ceil.k;
        stop = (match m.cn_up { Some(k) => k, None => entry + step }) + osh;
        target = if king.k < spot { if m.gk_f.state == "node" { m.gk_f.k.unwrap() } else { king.k } }
            else if let Some(f) = m.floor { f.k } else if entry > spot { entry - 2.0 * (entry - spot) } else { entry - osh };
    }
    let risk = { let r = (entry - stop).abs(); if r != 0.0 { r } else { 1e-9 } };
    Some(GPlan { up, entry, stop: fixed(stop, 4), target, rr: fixed((target - entry).abs() / risk, 2), osh: fixed(osh, 4) })
}

/// The two theses: numbered steps in PRICE order, named nodes only, no probability words.
pub fn glitch_thesis(sym: &str, m: &FrontMap, up: bool) -> String {
    let f = |v: f64| px(sym, v);
    let (floor, ceil, king, spot) = (m.floor, m.ceiling, m.king, m.spot);
    let pk = if up { &m.pk_up } else { &m.pk_dn };
    let gk = if up { &m.gk_c } else { &m.gk_f };
    let gk_txt = if gk.state == "node" { " — a Gatekeeper on the path, clear it first" } else { "" };
    let mut s: Vec<String> = Vec::new();
    if up {
        let mut t = format!("UPSIDE — 1. if {} holds the {} floor", sym, floor.map(|x| f(x.k)).unwrap_or_else(|| "n/a".into()));
        if let Some(fl) = floor { t += if fl.v > 0.0 { " (a Pika cushion, yellow +γ)" } else { " (a Barney pit, purple −γ: a reclaim, not a bounce, is needed)" }; }
        let k_on = king.k > spot;
        let k_mid = k_on && ceil.map_or(false, |c| king.k < c.k);
        if pk.state == "pocket" { s.push(format!("the air pocket above runs to {} — a level, not a speed", f(pk.to.unwrap()))); }
        if k_mid { s.push(format!("the King at {} sits on the way, under that ceiling — a pin: trade toward it, not through it", f(king.k))); }
        if let Some(c) = ceil { s.push(format!("the {} ceiling is the {} magnet{}", f(c.k), if k_mid { "next" } else { "first" }, gk_txt)); }
        if k_on && !k_mid && !ceil.map_or(false, |c| king.k == c.k) { s.push(format!("the King at {} is the destination{} — ride toward it, never through it", f(king.k), if ceil.is_some() { " if that ceiling gives way" } else { "" })); }
        for (i, x) in s.iter().enumerate() { t += &format!(" · {}. {}", i + 2, x); }
        t += if ceil.map_or(false, |c| king.k == c.k) { " — and that ceiling IS the King." } else { "." };
        return t;
    }
    let mut t = format!("DOWNSIDE — 1. if {} rejects at the {} ceiling", sym, ceil.map(|x| f(x.k)).unwrap_or_else(|| "n/a".into()));
    if let Some(c) = ceil { t += if c.v < 0.0 { " (a Barney lid, purple −γ: the rejection can accelerate)" } else { " (a Pika lid, yellow +γ)" }; }
    let k_on = king.k < spot;
    let k_mid = k_on && floor.map_or(false, |fl| king.k > fl.k);
    if pk.state == "pocket" { s.push(format!("the air pocket below runs to {} — a level, not a speed", f(pk.to.unwrap()))); }
    if k_mid { s.push(format!("the King at {} sits on the way, above that floor — a pin: trade toward it, not through it", f(king.k))); }
    if let Some(fl) = floor { s.push(format!("the {} floor is the {} magnet{}", f(fl.k), if k_mid { "next" } else { "first" }, gk_txt)); }
    if k_on && !k_mid && !floor.map_or(false, |fl| king.k == fl.k) { s.push(format!("the King at {} is the downside destination{} — ride toward it, never through it", f(king.k), if floor.is_some() { " if that floor gives way" } else { "" })); }
    for (i, x) in s.iter().enumerate() { t += &format!(" · {}. {}", i + 2, x); }
    t += if floor.map_or(false, |fl| king.k == fl.k) { " — and that floor IS the King." } else { "." };
    t
}

/// The scan-time read off the front map and the untrimmed rows. `plan` (optional) feeds the magnitude filter only.
pub fn glitch_of(m: &FrontMap, rows: &[Row], exps: &[String], spot: f64, sym: &str, plan: Option<&Plan>) -> Option<Glitch> {
    if rows.is_empty() || !(spot > 0.0) { return None; }
    let kmag = if m.king.v.abs() != 0.0 { m.king.v.abs() } else { 1.0 };
    let sig = SIG * kmag;
    let mut ladder: Vec<Gc> = rows.iter().map(|r| Gc { k: r.strike, g: if r.gx.is_empty() { r.g_near } else { r.gx[0] } }).collect();
    ladder.sort_by(|a, b| a.k.partial_cmp(&b.k).unwrap());
    let front_cells: Vec<Cl> = ladder.iter().filter(|c| c.g != 0.0).map(|c| Cl { k: c.k, e: 0, v: c.g }).collect();
    let front_tax = classify(&front_cells);
    let mut full_cells: Vec<Cl> = Vec::new();
    for r in rows { for (e, &g) in r.gx.iter().enumerate() { if g != 0.0 && !g.is_nan() { full_cells.push(Cl { k: r.strike, e, v: g }); } } }
    let full_tax = classify(&full_cells);
    let fm = full_map(rows, exps, spot);
    let (ceil, floor) = (m.ceiling, m.floor);
    let ds_a = double_stack(&ladder, spot, sig, true);
    let ds_b = double_stack(&ladder, spot, sig, false);
    let patterns = Patterns {
        rugpull: matches!((ceil, floor), (Some(c), Some(f)) if c.v >= sig && f.v <= -sig && m.pk_dn.state == "pocket"),
        reverse_rugpull: matches!((ceil, floor), (Some(c), Some(f)) if f.v >= sig && c.v <= -sig && m.pk_up.state == "pocket"),
        pocket_up: m.pk_up.state == "pocket", pocket_dn: m.pk_dn.state == "pocket",
        ds_ceil: ds_a.as_ref().map_or(false, |d| d.clean), ds_floor: ds_b.as_ref().map_or(false, |d| d.clean), ds_a, ds_b,
    };
    let cell = |b: Option<Bound>| b.map(|b| Cell { k: b.k, v: js_round(b.v), rung: b.rung });
    let near = |k: Option<f64>| -> Option<f64> {
        let k = k?; let mut b: Option<Gc> = None;
        for &c in &ladder { if b.map_or(true, |x| (c.k - k).abs() < (x.k - k).abs()) { b = Some(c); } }
        b.map(|b| js_round(b.g))
    };
    let plan_mag = plan.map(|p| PlanMag { tp1: near(p.tp_near), inv: near(p.invalidation) });
    let pko = |p: &Pocket| PocketOut { state: p.state.clone(), to: p.to, neg: p.neg, rungs: p.rungs };
    Some(Glitch {
        v: 1, sig: js_round(sig), spot, n_exps: exps.len(), front_exp: exps.first().cloned(),
        front: Front { king: cell(Some(m.king)).unwrap(), pit: m.pit, ceiling: cell(ceil), floor: cell(floor), gk_c: m.gk_c.clone(), gk_f: m.gk_f.clone(),
            pk_up: pko(&m.pk_up), pk_dn: pko(&m.pk_dn), cn_up: m.cn_up, cn_dn: m.cn_dn, nodes: role_of(&front_tax) },
        full: fm.map(|f| Full { king: f.king, ceil: f.ceil, floor: f.floor, t2: f.t2, nodes: role_of(&full_tax) }),
        patterns, plan_mag,
        plan: Plans { l: glitch_plan(sym, spot, m, true), s: glitch_plan(sym, spot, m, false) },
        thesis: Thesis { up: glitch_thesis(sym, m, true), dn: glitch_thesis(sym, m, false) },
        wear: None,
    })
}

/// Book → read, in one call. `plan` is optional (the judge's magnitude filter reads it).
pub fn glitch_read(b: &Book, plan: Option<&Plan>) -> Option<Glitch> {
    let rows = rows_of(b);
    let m = front_map(&rows, b.spot)?;
    glitch_of(&m, &rows, &b.expiries, b.spot, &b.symbol, plan)
}

// ═══════════════════════════════════════════════ 8. Wear & reach (daily bars) ═══════════════════════════════════════

/// Taps: how many of the last 10 bars traded through `k`.
pub fn tap_count(bars: &[Bar], k: Option<f64>) -> Option<usize> {
    let k = k?;
    let last = &bars[bars.len().saturating_sub(10)..];
    if last.is_empty() { return None; }
    Some(last.iter().filter(|b| b.l <= k && k <= b.h).count())
}

/// Taps at the floor / ceiling / target / stop, the session range, and fresh / in-play / delivered per level.
pub fn glitch_wear(g: &mut Glitch, bars: &[Bar], spot: f64, end: Option<&str>, plan: Option<&Plan>) {
    if bars.is_empty() { return; }
    let last: Vec<Bar> = bars.iter().filter(|b| end.map_or(true, |e| e.is_empty() || b.d.as_str() <= e)).cloned().collect();
    let Some(today) = last.last().cloned() else { return };
    let touched = |k: f64| today.l <= k * 1.002 && today.h >= k * 0.998;
    let deliv = |k: Option<f64>| -> Option<String> {
        let k = k?;
        Some(if !touched(k) { "fresh" } else if spot > 0.0 && (spot - k).abs() / k >= DELIVER { "delivered" } else { "in-play" }.into())
    };
    let fk = g.front.floor.as_ref().map(|c| c.k);
    let ck = g.front.ceiling.as_ref().map(|c| c.k);
    g.wear = Some(Wear {
        session: today.d.clone(),
        range: if today.h > 0.0 && today.l > 0.0 && spot > 0.0 { Some(fixed((today.h - today.l) / spot * 100.0, 2)) } else { None },
        taps: Taps { floor: tap_count(&last, fk), ceiling: tap_count(&last, ck), tp1: plan.and_then(|p| tap_count(&last, p.tp_near)), inv: plan.and_then(|p| tap_count(&last, p.invalidation)) },
        delivered: Delivered { floor: deliv(fk), ceiling: deliv(ck), ote: plan.and_then(|p| deliv(p.ote)) },
    });
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct ReachOne { pub k: f64, pub tag: String, pub ratio: f64, pub wear: usize, pub rate: f64, pub n: f64 }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Reach { pub floor: Option<ReachOne>, pub ceiling: Option<ReachOne> }

pub fn reach_tag(ratio: f64, wear: Option<usize>) -> Option<&'static str> {
    let w = wear?; if !(ratio >= 0.0) { return None; }
    Some(if w >= 3 { "WORN" } else if w >= 1 { "TESTED" } else if ratio >= REACH_RATIO_CUT { "FRESH-BIG" } else { "THIN" })
}
fn reach_wear(bars: &[Bar], k: f64, end: Option<&str>) -> Option<usize> {
    let f: Vec<&Bar> = bars.iter().filter(|b| end.map_or(true, |e| e.is_empty() || b.d.as_str() <= e)).collect();
    let last = &f[f.len().saturating_sub(5)..];
    if last.is_empty() { return None; }
    Some(last.iter().filter(|b| b.l <= k && k <= b.h).count())
}
/// REACH tags on the FRONT floor and ceiling. TOUCH odds only — never hold, never a side.
pub fn reach_of(g: &Glitch, bars: &[Bar], end: Option<&str>) -> Option<Reach> {
    let kk = g.front.king.v.abs(); if !(kk > 0.0) { return None; }
    let one = |b: &Option<Cell>| -> Option<ReachOne> {
        let b = b.as_ref()?;
        let ratio = fixed(b.v.abs() / kk, 3);
        let w = reach_wear(bars, b.k, end);
        let tag = reach_tag(ratio, w)?; let s = reach_spec(tag);
        Some(ReachOne { k: b.k, tag: tag.into(), ratio, wear: w.unwrap(), rate: s.rate, n: s.n })
    };
    let (floor, ceiling) = (one(&g.front.floor), one(&g.front.ceiling));
    if floor.is_none() && ceiling.is_none() { None } else { Some(Reach { floor, ceiling }) }
}

// ═══════════════════════════════════════════════ 9. Trinity · regime · the judge ════════════════════════════════════

/// One card of the board for the Trinity read: the symbol, its spot, and its FULL-map King strike.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IndexCard { pub sym: String, pub spot: f64, #[serde(rename = "kingK")] pub king_k: Option<f64>, #[serde(default)] pub error: bool }
impl IndexCard {
    /// `error` = the book for this symbol failed to load (the card is skipped, as a failed card is on the board).
    pub fn of(sym: &str, g: Option<&Glitch>, spot: f64, error: bool) -> IndexCard { IndexCard { sym: sym.into(), spot, king_k: g.and_then(|g| g.full.as_ref()).and_then(|f| f.king.as_ref()).map(|k| k.k), error } }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Biases { #[serde(rename = "SPY")] pub spy: Option<String>, #[serde(rename = "QQQ")] pub qqq: Option<String>, #[serde(rename = "SPXW")] pub spxw: Option<String> }
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Trinity { pub biases: Biases, pub score: u32, pub aligned: bool, pub aligned2: bool, pub vix: Option<f64>, #[serde(rename = "vixSrc")] pub vix_src: Option<String> }

/// SPX / SPY / QQQ bias off the board's own index cards; VIX from the board's VIX card, else `vix_fallback`.
pub fn trinity(list: &[IndexCard], vix_fallback: Option<f64>) -> Trinity {
    let bias = |c: Option<&IndexCard>| -> Option<String> {
        let c = c?; let k = c.king_k?; if !(c.spot > 0.0) { return None; }
        let d = (k - c.spot) / c.spot;
        Some(if d.abs() < NEUTRAL { "NEUTRAL" } else if d > 0.0 { "BULLISH" } else { "BEARISH" }.into())
    };
    let find = |s: &str| list.iter().find(|c| c.sym == s && !c.error);
    let by = Biases { spy: bias(find("SPY")), qqq: bias(find("QQQ")), spxw: bias(find("SPXW")) };
    let vals: Vec<&String> = [&by.spy, &by.qqq, &by.spxw].iter().filter_map(|v| v.as_ref()).filter(|v| *v == "BULLISH" || *v == "BEARISH").collect();
    let bulls = vals.iter().filter(|v| **v == "BULLISH").count();
    let score = if vals.is_empty() { 0 } else { bulls.max(vals.len() - bulls) as u32 };
    let vx = list.iter().find(|c| c.sym == "VIX" && !c.error && c.spot > 0.0);
    let dir = |v: &Option<String>| matches!(v.as_deref(), Some("BULLISH") | Some("BEARISH"));
    Trinity {
        aligned: score == 3 && vals.len() == 3, aligned2: by.spy == by.qqq && dir(&by.spy),
        score, vix: vx.map(|c| c.spot).or(vix_fallback), vix_src: if vx.is_some() { Some("board".into()) } else if vix_fallback.is_some() { Some("pivot".into()) } else { None },
        biases: by,
    }
}

/// VIX > 25 → VOL_EVENT; else range × SPY/QQQ alignment; no session range → UNREAD (never CHOP by default).
pub fn regime(trin: &Trinity, range_pct: Option<f64>) -> &'static str {
    if trin.vix.map_or(false, |v| v > 25.0) { return "VOL_EVENT"; }
    let Some(r) = range_pct else { return "UNREAD" };
    let al = trin.aligned2;
    if !al && r < 0.3 { return "CHOP"; }
    if al && r >= 0.8 { return "TREND"; }
    if !al && r >= 0.5 { return "WHIPSAW"; }
    "CHOP"
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Filters {
    pub f1: bool, pub f2: bool, pub f3: bool, pub f4: bool, pub f5: bool,
    pub delivered: Option<String>, pub regime: String,
    #[serde(rename = "tapsTp1")] pub taps_tp1: Option<usize>, #[serde(rename = "tapsInv")] pub taps_inv: Option<usize>,
    pub rr: f64, pub trinity: u32,
    #[serde(rename = "magTp1")] pub mag_tp1: Option<f64>, #[serde(rename = "magInv")] pub mag_inv: Option<f64>,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Judge { pub verdict: String, pub score: u32, pub reason: Option<String>, pub filters: Option<Filters>, pub unmeasured: Vec<String> }

/// The doctrine's five filters on an outside plan. A checklist, never a probability (INVERTED in training).
/// F1 delivery/regime · F2 re-test ≤ 2 · F3 R:R ≥ 3 · F4 Trinity 3/3 · F5 node magnitude.
pub fn judge(plan: Option<&Plan>, g: Option<&Glitch>, trin: &Trinity, regime: &str) -> Judge {
    let ok = matches!(plan, Some(p) if p.ote.is_some() && p.tp_near.is_some() && p.invalidation.is_some());
    let (Some(s), Some(g), true) = (plan, g, ok) else {
        return Judge { verdict: "NO PLAY".into(), score: 0, reason: Some("the engine has no plan on this card".into()), filters: None, unmeasured: vec![] };
    };
    let w = g.wear.as_ref();
    let rr = s.rr_near.filter(|x| !x.is_nan()).unwrap_or(0.0);
    let d_ote = w.and_then(|w| w.delivered.ote.clone());
    let t_t = w.and_then(|w| w.taps.tp1);
    let t_i = w.and_then(|w| w.taps.inv);
    let (pm_t, pm_i) = g.plan_mag.as_ref().map_or((None, None), |p| (p.tp1, p.inv));
    let f1 = regime != "CHOP" && d_ote.as_deref() != Some("delivered");
    let f2 = matches!((t_t, t_i), (Some(a), Some(b)) if a <= 2 && b <= 2);
    let f3 = rr >= 3.0;
    let f4 = trin.aligned;
    let f5 = matches!((pm_t, pm_i), (Some(a), Some(b)) if a.abs() >= MAG && b.abs() >= MAG);
    let score = (if f1 { 20 } else { 0 }) + (if f2 { 20 } else { 5 }) + (if f3 { 25 } else { 0 }) + (if f4 { 20 } else if trin.score == 2 { 10 } else { 0 }) + (if f5 { 15 } else { 0 });
    let verdict = if score >= 85 && f3 && f1 { "A+ PLAY" } else if score >= 60 && f3 && f1 { "VALID SETUP" } else { "NO PLAY" };
    let mut un = Vec::new();
    if d_ote.is_none() { un.push("delivery (no session bars)".to_string()); }
    if t_t.is_none() { un.push("re-test (no session bars)".to_string()); }
    Judge { verdict: verdict.into(), score, reason: None,
        filters: Some(Filters { f1, f2, f3, f4, f5, delivered: d_ote, regime: regime.into(), taps_tp1: t_t, taps_inv: t_i, rr: fixed(rr, 2), trinity: trin.score, mag_tp1: pm_t, mag_inv: pm_i }),
        unmeasured: un }
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Take { pub take: bool, pub verdict: String, pub score: u32, pub fails: Vec<String>, pub unread: Vec<String>, pub regime: String, pub trinity: u32 }

/// TAKE when the judge passes the plan (A+ or VALID), NO when it reads NO PLAY, None with no plan.
pub fn take(plan: Option<&Plan>, g: Option<&Glitch>, trin: &Trinity) -> Option<Take> {
    let g = g?; let p = plan?;
    if p.ote.is_none() || p.tp_near.is_none() || p.invalidation.is_none() { return None; }
    let reg = regime(trin, g.wear.as_ref().and_then(|w| w.range));
    let j = judge(plan, Some(g), trin, reg);
    let f = j.filters.as_ref()?;
    let fails: Vec<String> = [(!f.f1, "delivery/regime"), (!f.f2, "re-test"), (!f.f3, "R:R ≥ 3"), (!f.f4, "Trinity 3/3"), (!f.f5, "magnitude")].iter().filter(|x| x.0).map(|x| x.1.to_string()).collect();
    Some(Take { take: j.verdict != "NO PLAY", verdict: j.verdict.clone(), score: j.score, fails, unread: j.unmeasured.clone(), regime: reg.into(), trinity: trin.score })
}

// ═══════════════════════════════════════════════ 10. The box ════════════════════════════════════════════════════════

/// Everything the box prints for one ticker.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct GlitchBox {
    pub sym: String,
    /// odte · dte2 · dte3 · swing · leaps — the plan's tenor (labels the judge arm); None = "plan"
    pub mode: Option<String>,
    pub plan: Option<Plan>,
    /// "grew" / "decayed" when you track the King cell across sessions; None otherwise
    #[serde(rename = "kingTrend")] pub king_trend: Option<String>,
    pub glitch: Glitch,
    pub reach: Option<Reach>,
    pub trinity: Trinity,
    pub regime: String,
    pub judge: Judge,
    pub take: Option<Take>,
}

pub fn build_box(sym: &str, g: Glitch, bars: &[Bar], end: Option<&str>, plan: Option<Plan>, mode: Option<String>, king_trend: Option<String>, trin: Trinity) -> GlitchBox {
    let mut g = g;
    let spot = g.spot;
    if !bars.is_empty() { glitch_wear(&mut g, bars, spot, end, plan.as_ref()); }
    let reach = if bars.is_empty() { None } else { reach_of(&g, bars, end) };
    let reg = regime(&trin, g.wear.as_ref().and_then(|w| w.range));
    let j = judge(plan.as_ref(), Some(&g), &trin, reg);
    let t = take(plan.as_ref(), Some(&g), &trin);
    GlitchBox { sym: sym.into(), mode, plan, king_trend, glitch: g, reach, trinity: trin, regime: reg.into(), judge: j, take: t }
}

fn mode_label(m: &str) -> String { match m { "odte" => "ODTE".into(), "dte2" => "2DTE".into(), "dte3" => "3DTE".into(), "swing" => "SWING".into(), "leaps" => "LEAPS".into(), x => x.to_string() } }
fn short_exp(e: &str) -> String { e.chars().skip(5).collect() }

/// The box as plain text. `verbose` adds each pill's explanation under it.
pub fn render_text(b: &GlitchBox, verbose: bool) -> String {
    let g = &b.glitch; let sym = b.sym.as_str(); let spot = g.spot;
    let f = |v: Option<f64>| pxo(sym, v);
    let mut o = String::new();
    let mut line = |s: String| { o.push_str(&s); o.push('\n'); };
    let note = |s: &str| -> String { if verbose { format!("\n      ↳ {}", s) } else { String::new() } };
    line(format!("👁 GLITCH READS THE MAP · {} · front & full · structures · regime · the judge · both theses · {} measured base rates · display only", sym, thousands(base_rates().len() as f64)));
    if verbose { line(format!("   ↳ {}", HEAD_TIP)); }

    // FRONT
    let node_line = |n: &Node, map: &str| -> String {
        let glyph = match n.r.as_str() { "king" => "👑", "pika" => "🟡", "barney" => "🟣", "gatekeeper" => "🚧", _ => "·" };
        let k = |m: &str| node_key(m, map, &n.r, n.v, n.k, spot);
        format!("   {} {} {} · {}% {}{}{}{}{}", glyph, px(sym, n.k), fmt_k(n.v), dist_bucket(n.k, spot), if n.k > spot { "above" } else { "below" },
            cite(&k("touch"), "touched"), cite(&k("hold"), "held"), cite(&k("break"), "broke"),
            cite(&format!("glitch.overshoot.p50.map={}.role={}.sign={}.side={}", map, n.r, if n.v < 0.0 { "neg" } else { "pos" }, if n.k > spot { "above" } else { "below" }), "overshoot p50"))
    };
    let by_price = |nodes: &[Node], map: &str| -> Vec<String> {
        let mut l2 = nodes.to_vec(); l2.sort_by(|a, b| b.k.partial_cmp(&a.k).unwrap());
        let mut out: Vec<String> = l2.iter().filter(|n| n.k > spot).map(|n| node_line(n, map)).collect();
        out.push(format!("   ▸ {} spot", px(sym, spot)));
        out.extend(l2.iter().filter(|n| n.k <= spot).map(|n| node_line(n, map)));
        out
    };
    let gk = |g: &Gate| -> String { if g.state == "node" { format!("{}{}", f(g.k), if g.in_path == Some(false) { " (behind the King)" } else { "" }) } else { g.state.clone() } };
    line(String::new());
    line(format!("FRONT MAP · {} · spot {}", g.front_exp.as_deref().map(short_exp).unwrap_or_else(|| "expiry 0".into()), px(sym, spot)));
    line(format!("   👑 King {} ({} · {}) · ceiling {} · floor {}", px(sym, g.front.king.k), if g.front.pit { "purple pit" } else { "yellow peak" }, fmt_k(g.front.king.v),
        f(g.front.ceiling.as_ref().map(|c| c.k)), f(g.front.floor.as_ref().map(|c| c.k))));
    if let Some(r) = &b.reach {
        let one = |lbl: &str, x: &Option<ReachOne>| x.as_ref().map(|x| format!("{} {} ({}% of {} · {}× King · {} of 5)", lbl, x.tag, js_num(x.rate), thousands(x.n), js_num(x.ratio), x.wear));
        let parts: Vec<String> = [one("floor", &r.floor), one("ceiling", &r.ceiling)].into_iter().flatten().collect();
        line(format!("   🧱 REACH {}{}", parts.join(" · "), note(&format!("REACH = the odds the level is TOUCHED next session (holdout Jan-2026, 20,764 bound rows): {}. A bound is touched MORE than a same-distance random strike and HELD LESS once touched — this tag never says hold, never says a side, feeds nothing.",
            REACH_TAGS.iter().map(|t| format!("{} {}% of {} ({})", t.tag, js_num(t.rate), js_num(t.n), t.rule)).collect::<Vec<_>>().join(" · ")))));
    }
    for s in by_price(&g.front.nodes, "front") { line(s); }
    line(format!("   🚧 gatekeeper up {} · down {}", gk(&g.front.gk_c), gk(&g.front.gk_f)));

    // FULL
    line(String::new());
    line(format!("FULL MAP · {} expiries · largest single cell, never a sum", g.n_exps));
    match &g.full {
        Some(fu) => {
            let ex = |c: &Option<FullCell>| c.as_ref().map(|c| short_exp(&c.e)).unwrap_or_default();
            line(format!("   👑 King {} ({} · {}) · ceiling {} ({}) · floor {} ({})", f(fu.king.as_ref().map(|c| c.k)), ex(&fu.king), fmt_ko(fu.king.as_ref().map(|c| c.g)),
                f(fu.ceil.as_ref().map(|c| c.k)), ex(&fu.ceil), f(fu.floor.as_ref().map(|c| c.k)), ex(&fu.floor)));
            for s in by_price(&fu.nodes, "full") { line(s); }
        }
        None => line("   no full map on this card".into()),
    }

    // STRUCTURES
    let p = &g.patterns;
    let kp = if g.front.pit { "king_pit" } else { "king_peak" };
    let pat_c = |name: &str| format!("{}{}", cite(&format!("glitch.pattern.plan_money_h5.pattern={}", name), "deflection plan $/1k"), cite(&format!("glitch.pattern.plan_tp_h5.pattern={}", name), "hit"));
    let mut st: Vec<String> = Vec::new();
    if p.rugpull { st.push(format!("⚠ RUGPULL SETUP · as a direction {}% vs a {}% coin{}{}", js_num(cal::RUGPULL[1]), js_num(cal::RUGPULL[2]), pat_c("rugpull"),
        note(&format!("yellow ceiling above, purple pit below, air pocket between (doctrine). DOCTRINE-ONLY as a direction: on {} boards its direction call hit {}% against a {}% board coin — below the coin. A shape on the map, not a call.", js_num(cal::RUGPULL[0]), js_num(cal::RUGPULL[1]), js_num(cal::RUGPULL[2]))))); }
    if p.reverse_rugpull { st.push(format!("🎢 REVERSE RUGPULL · as a direction {}% vs a {}% coin{}{}", js_num(cal::REVERSE_RUGPULL[1]), js_num(cal::REVERSE_RUGPULL[2]), pat_c("reverse_rugpull"),
        note(&format!("yellow floor cushion, purple accelerant above (doctrine). DOCTRINE-ONLY as a direction: {}% against a {}% board coin on {} boards — below the coin.", js_num(cal::REVERSE_RUGPULL[1]), js_num(cal::REVERSE_RUGPULL[2]), js_num(cal::REVERSE_RUGPULL[0]))))); }
    if p.ds_ceil { let d = p.ds_a.as_ref(); st.push(format!("🟡🟡 DOUBLE-STACKED CEILING · direction a coin · the deflection plan off it ${}/1k p {}{}{}", js_num(cal::DS_CEIL.1), js_num(cal::DS_CEIL.4), pat_c("ds_ceiling"),
        note(&format!("two yellow nodes stacked above spot ({} / {}). MEASURED: the deflection plan off this shape paid ${} per $1k a fill on {} fills, per-symbol {}/{} (p {}, the one BH survivor) — while its own DIRECTION call stayed a coin (55% vs a 65% board coin).",
            f(d.map(|d| d.n1)), f(d.map(|d| d.n2)), js_num(cal::DS_CEIL.1), js_num(cal::DS_CEIL.0), js_num(cal::DS_CEIL.2), js_num(cal::DS_CEIL.3), js_num(cal::DS_CEIL.4))))); }
    if p.ds_floor { let d = p.ds_b.as_ref(); st.push(format!("🟡🟡 DOUBLE-STACKED FLOOR · direction a coin · the floor mirror does not clear the bar{}{}", pat_c("ds_floor"),
        note(&format!("two yellow nodes stacked below spot ({} / {}). DOCTRINE-ONLY: walked $63.9 per $1k on 357 fills but per-symbol 99/75, p 0.081 — does not clear the bar.", f(d.map(|d| d.n1)), f(d.map(|d| d.n2)))))); }
    if p.pocket_up { st.push(format!("💨 AIR POCKET ABOVE → {} · a level, not a speed{}{}{}{}", f(g.front.pk_up.to), cite("glitch.pocket.traverse.dirn=up", "far end reached"), cite("glitch.pocket.traverse_min.dirn=up", "minutes p50"), cite("glitch.intraday.pocket.traverse.side=up", "intraday"),
        note("an unbroken run of sub-significant strikes between spot and the next structure (doctrine: price crosses it fast). The level is real; the SPEED claim measured null against a same-width obstructed control — print the level, never a \"fast move\"."))); }
    if p.pocket_dn { st.push(format!("💨 AIR POCKET BELOW → {} · a level, not a speed{}{}{}{}", f(g.front.pk_dn.to), cite("glitch.pocket.traverse.dirn=dn", "far end reached"), cite("glitch.pocket.traverse_min.dirn=dn", "minutes p50"), cite("glitch.intraday.pocket.traverse.side=dn", "intraday"),
        note("an unbroken run of sub-significant strikes between spot and the next structure below. The level is real; the SPEED claim measured null — print the level, never a \"fast move\"."))); }
    let gks = &g.front.gk_c.state;
    st.push(format!("🚧 GATEKEEPER {}{}{}{}{}", gks, cite("glitch.gatekeeper.state_freq.state=node", "boards with one"), cite(&format!("glitch.gatekeeper.reach_king.state={}", gks), &format!("King reached · {}", gks)), cite("glitch.gatekeeper.reach_king.state=open", "open"),
        note("the biggest node ≥ ¼ King strictly between the King and its bound; state node = a real gatekeeper on the path, open = none, pinned = the King is the bound")));
    st.push(format!("👑 KING {} {}{}{}{}{}", if g.front.pit { "PIT" } else { "PEAK" }, px(sym, g.front.king.k), cite("glitch.king.persist", "persists next session"), cite("glitch.king.migrate_with_price", "moves with price when it moves"), cite("glitch.intraday.king.persist", "intraday pull→pull"),
        note("the largest |γ| cell of the front column; pit = negative")));
    match b.king_trend.as_deref() {
        Some("grew") => st.push(format!("👑 KING GREW{}", note(&format!("the King cell grew past its tenor floor since the prior session. MEASURED: a grown King was TOUCHED next session {}% vs {}% flat (per-symbol p {}) — attraction only; its hold rate was flat. Never a direction.", js_num(cal::GREW_KING[1]), js_num(cal::GREW_KING[2]), js_num(cal::GREW_KING[3]))))),
        Some("decayed") => st.push(format!("👑 KING DECAYED{}", note("the King cell decayed past its tenor floor since the prior session — a fact about the book; decay measured nothing about the next session."))),
        _ => {}
    }
    line(String::new());
    line("STRUCTURES".into());
    for s in st { line(format!("   {}", s)); }

    // REGIME + TRINITY
    let trin = &b.trinity; let reg = b.regime.as_str();
    let reg_word = match reg { "TREND" => "📈 TREND", "WHIPSAW" => "🌀 WHIPSAW", "CHOP" => "📦 CHOP", "VOL_EVENT" => "🌋 VOL EVENT", "UNREAD" => "⚪ REGIME UNREAD", x => x };
    let reg_key = reg.to_lowercase();
    let range = g.wear.as_ref().and_then(|w| w.range);
    let reg_tip = if reg == "UNREAD" { format!("no session range on this card (no daily bars) — VIX alone reads {}. The table needs the session's range; a missing range is UNREAD, never CHOP by default.", trin.vix.map(js_num).unwrap_or_else(|| "nothing".into())) }
        else { format!("VIX {} · session range {} · SPY/QQQ {}. A LABEL: regime-conditional payoffs were fat-tail artifacts on thin cells in training and are not printed; the share of boards and the next-session up rate beside it are base rates, judged against the board coin, never 50%.",
            trin.vix.map(|v| format!("{}{}", js_num(v), if trin.vix_src.as_deref() == Some("board") { " (this board)" } else { " (pivot)" })).unwrap_or_else(|| "n/a".into()), range.map(|r| format!("{}%", js_num(r))).unwrap_or_else(|| "n/a".into()), if trin.aligned2 { "aligned" } else { "not aligned" }) };
    let bw = |v: &Option<String>| v.as_ref().map(|s| format!("{}{}", &s[..1], s[1..4].to_lowercase())).unwrap_or_else(|| "—".into());
    line(String::new());
    line(format!("REGIME {}{}{} · Trinity {}/3{}{} · SPY {} · QQQ {} · SPXW {}{}", reg_word,
        if reg != "UNREAD" { cite(&format!("glitch.regime.freq.regime={}", reg_key), "share of boards") + &cite(&format!("glitch.regime.next_up.regime={}", reg_key), "next session up") } else { String::new() },
        note(&reg_tip), trin.score, cite(&format!("glitch.trinity.freq.score={}", trin.score), &format!("{}/3 of boards", trin.score)), cite("glitch.trinity.freq.score=3", "3/3"),
        bw(&trin.biases.spy), bw(&trin.biases.qqq), bw(&trin.biases.spxw), note(TRIN_TIP)));

    // JUDGE
    let j = &b.judge;
    let arm = match b.mode.as_deref() { Some("odte") | Some("dte2") | Some("dte3") => "dte3", _ => "swing" };
    let arm_lab = b.mode.as_deref().map(mode_label).unwrap_or_else(|| "plan".into());
    line(String::new());
    line(format!("GLITCH JUDGES THE {} PLAN · {} · score {}/100 · a checklist, not odds — INVERTED in training{}{}", arm_lab, j.verdict, j.score,
        if j.unmeasured.is_empty() { String::new() } else { format!(" · unread: {}", j.unmeasured.join(", ")) }, note(JUDGE_TIP)));
    match &j.filters {
        Some(fj) => {
            let tick = |ok: bool| if ok { "→ PASS" } else { "→ FAIL" };
            let tap = |n: Option<usize>| match n { None => "unread".to_string(), Some(0) => "fresh".into(), Some(1) => "1st test".into(), Some(2) => "2nd test".into(), Some(x) => format!("3rd+ test ({}×)", x) };
            let f1why = if reg == "CHOP" { "CHOP: sit on hands, the doctrine kills it regardless of the node".to_string() } else { match fj.delivered.as_deref() {
                Some("delivered") => "delivered: the target was already tapped and left — delivery narrows the odds, it does not zero them".into(),
                Some("fresh") => format!("fresh entries paid more in training ({} per $1k a fill, per-symbol p {} — marginal, tail-carried)", if arm == "dte3" { "$109 vs $5" } else { "$165 vs $4" }, if arm == "dte3" { "0.07" } else { "0.39" }),
                Some("in-play") => "in play: the entry was touched this session and price is still within 0.3% of it — the setup is live now".into(),
                _ => "no session bars to read delivery from".into() } };
            line(format!("   [F1 Price delivery · entry {} · regime {}] {} — {}{}{}{}", fj.delivered.as_deref().unwrap_or("unread"), reg, tick(fj.f1), f1why,
                cite("glitch.delivery.outcome.state=fresh.role=king.tp", "fresh King-class entry hit"), cite("glitch.delivery.outcome.state=delivered.role=king.tp", "delivered"), cite("glitch.intraday.delivery.retouch", "a delivered level re-touched before the close")));
            let retest: String = ["0", "1", "2", "3plus"].iter().map(|t| cite(&format!("glitch.retest.hold.role=pika.tests={}", t), &format!("{}×", t.replace("plus", "+")))).collect();
            line(format!("   [F2 Retest ≤ 2 · target {} · stop {}] {} — the 66% / 33% decay measured {}% vs {}% — a coin (n {}); strict hold by prior tests, Pika:{} — worn nodes held MORE",
                tap(fj.taps_tp1), tap(fj.taps_inv), tick(fj.f2), js_num(cal::RETEST.1), js_num(cal::RETEST.2), thousands(cal::RETEST.0), retest));
            line(format!("   [F3 R:R ≥ 3:1 · {}:1] {} — {}{}", js_num(fj.rr), tick(fj.f3),
                if fj.f3 { "on paper only: the high-hit-rate band is 0.5–1.5 and > 3 is the low-hit-rate band (TP1 53 → 38 → 19%) — a PASS here is not a PASS on money" } else { "the high-hit-rate band is 0.5–1.5 (TP1 53% vs 19% above 3:1) — a FAIL here is the band that hits most" },
                cite(&format!("glitch.judge.filter_pass.f3.arm={}", arm), "passes on")));
            line(format!("   [F4 Trinity 3/3 · {}/3] {} — a literal 3/3 occurred on 0 of 6,801 boards; 2/3 is the practical ceiling and aligned boards paid no more (per-symbol {}/{}, p {}){}",
                fj.trinity, tick(fj.f4), js_num(cal::TRINITY.0), js_num(cal::TRINITY.1), js_num(cal::TRINITY.2), cite("glitch.trinity.freq.score=3", "3/3 occurs on")));
            line(format!("   [F5 Node magnitude · target {} · stop {}] {} — the floor is ¼ of the King ({}), a ratio — the 4-digit rule is unmeasured here",
                fmt_ko(fj.mag_tp1), fmt_ko(fj.mag_inv), tick(fj.f5), fmt_k(g.sig)));
            line(format!("   VERDICT {} · {}/100 · a paperwork score, never odds — INVERTED in training, {} money per $1k a fill:{}{} · VALID and A+ carry fewer than 100 fills each and sit BELOW it ({})",
                j.verdict, j.score, arm_lab, cite(&format!("glitch.judge.outcome.no_play.money.arm={}", arm), "NO PLAY"), cite(&format!("glitch.judge.outcome.no_play.tp.arm={}", arm), "hit"),
                if arm == "dte3" { "$29.4 · $1.1" } else { "$35.5 · −$2.8" }));
        }
        None => line(format!("   {} — Glitch still reads the map; the theses are a shape on the map, not a plan.", j.reason.as_deref().unwrap_or(""))),
    }

    // PLANS
    let gp = match b.plan.as_ref().and_then(|p| p.up) { Some(true) => g.plan.l.as_ref(), Some(false) => g.plan.s.as_ref(), None => g.plan.l.as_ref().or(g.plan.s.as_ref()) };
    line(String::new());
    match gp {
        Some(gp) => {
            line(format!("🎯 GLITCH'S OWN {} · deflection {} · overshoot ±{}", if gp.up { "LONG" } else { "SHORT" }, if gp.up { "at the floor" } else { "at the ceiling" }, js_num(gp.osh)));
            line(format!("   entry {} · stop {} · target {} · R:R {}:1", px(sym, gp.entry), px(sym, gp.stop), px(sym, gp.target), js_to_fixed(gp.rr, 2)));
            line(format!("  {}{}{}{}", cite(&format!("glitch.pattern.plan_fill_h5.pattern={}", kp), &format!("on {} boards: filled", kp.replace('_', " "))), cite(&format!("glitch.pattern.plan_tp_h5.pattern={}", kp), "hit"),
                cite(&format!("glitch.pattern.plan_stop_h5.pattern={}", kp), "stopped"), cite(&format!("glitch.pattern.plan_money_h5.pattern={}", kp), "$/1k")));
        }
        None => line("🎯 no deflection plan (no bound on that side)".into()),
    }
    match &b.plan {
        Some(s) if s.ote.is_some() => line(format!("⚙ THE {} PLAN · {} · entry {} · stop {} · target {} · R:R {}:1", if s.up == Some(true) { "LONG" } else { "SHORT" }, arm_lab, f(s.ote), f(s.invalidation), f(s.tp_near), s.rr_near.map(|r| js_to_fixed(r, 2)).unwrap_or_else(|| "—".into()))),
        _ => line("⚙ no outside plan on this card".into()),
    }

    // THESES
    let roles = |n: &Option<Cell>| -> Option<String> { let n = n.as_ref()?; Some(if n.k == g.front.king.k { "king" } else if n.v > 0.0 { "pika" } else { "barney" }.into()) };
    let (fl, ce) = (&g.front.floor, &g.front.ceiling);
    let up_c = match fl { Some(fl0) => {
        let r = roles(fl).unwrap();
        let mut s = cite(&node_key("touch", "front", &r, fl0.v, fl0.k, spot), "this floor's class touched") + &cite(&node_key("hold", "front", &r, fl0.v, fl0.k, spot), "held");
        if let Some(c) = ce { s += &cite(&node_key("touch", "front", &roles(ce).unwrap(), c.v, c.k, spot), "ceiling touched"); }
        if p.pocket_up { s += &cite("glitch.pocket.traverse.dirn=up", "pocket far end reached"); }
        s } None => String::new() };
    let dn_c = match ce { Some(c) => {
        let r = roles(ce).unwrap();
        let mut s = cite(&format!("glitch.overshoot.p50.map=front.role={}.sign={}.side=above", r, if c.v < 0.0 { "neg" } else { "pos" }), "overshoot beyond it p50") + &cite(&node_key("break", "front", &r, c.v, c.k, spot), "broke");
        if let Some(fl0) = fl { s += &cite(&node_key("touch", "front", &roles(fl).unwrap(), fl0.v, fl0.k, spot), "floor touched"); }
        if p.pocket_dn { s += &cite("glitch.pocket.traverse.dirn=dn", "pocket far end reached"); }
        s } None => String::new() };
    line(String::new());
    line(format!("📈 {}{}", g.thesis.up, up_c));
    line(format!("📉 {}{} · a rolled ceiling or floor predicts nothing (rolling walls 48–51% vs a 63% board coin)", g.thesis.dn, dn_c));

    // SESSION
    line(String::new());
    line(format!("⏱ SESSION SHAPE{}{}{}{}{}{}{}", cite("glitch.session.high_first30", "high set in the first 30 min"), cite("glitch.session.low_first30", "low"), cite("glitch.session.close_vs_open_up", "close above open"),
        cite("glitch.session.lunch_range_share", "lunch range share"), cite("glitch.session.last30_range_share", "last-30 share"), cite("glitch.intraday.front_decay.expiry=true.p50", "0DTE front King into the close on an expiry day ×"),
        cite("glitch.intraday.delivery.retouch", "a delivered floor/ceiling re-touched before the close")));
    line(String::new());
    line(FOOT.into());
    o
}

// ═══════════════════════════════════════════════ 11. Demo book & main ═══════════════════════════════════════════════

/// A synthetic book for `demo`: a yellow King above spot, a purple pit below, a gatekeeper on the way, three expiries.
pub fn demo_book() -> Book {
    let spot = 500.0;
    let strikes: Vec<f64> = (0..41).map(|i| 480.0 + i as f64).collect();
    let expiries = vec!["2026-10-06".to_string(), "2026-10-09".into(), "2026-10-16".into()];
    let bump = |k: f64, c: f64, w: f64, a: f64| a * (-((k - c) * (k - c)) / (2.0 * w * w)).exp();
    let mut gamma = Vec::new(); let mut vanna = Vec::new();
    for &k in &strikes {
        let g0 = bump(k, 510.0, 1.2, 9.0e6) + bump(k, 505.0, 0.8, 3.1e6) + bump(k, 497.0, 0.9, 2.6e6) - bump(k, 490.0, 1.0, 4.4e6) + 4.0e4 * ((k * 1.7).sin());
        let g1 = 0.6 * bump(k, 515.0, 1.5, 7.0e6) - 0.5 * bump(k, 488.0, 1.5, 3.0e6);
        let g2 = 0.4 * bump(k, 520.0, 2.0, 6.0e6) + 0.3 * bump(k, 495.0, 2.0, 2.0e6);
        gamma.push(vec![g0.round(), g1.round(), g2.round()]);
        vanna.push(vec![(1.5e5 * (k - spot)).round(), (2.0e5 * (k - spot + 3.0)).round(), (-1.0e5 * (k - spot - 8.0)).round()]);
    }
    Book { symbol: "DEMO".into(), spot, expiries, strikes, gamma, vanna }
}
pub fn demo_bars() -> Vec<Bar> {
    let mut v = Vec::new();
    for i in 0..12 { let c = 497.0 + (i as f64 * 0.7).sin() * 3.0; v.push(Bar { d: format!("2026-09-{:02}", 17 + i), h: c + 2.2, l: c - 2.0 }); }
    v
}

fn parse_plan(args: &[String]) -> Option<(Plan, String)> {
    let i = args.iter().position(|a| a == "--plan")?;
    let side = args.get(i + 1)?; let n = |j: usize| args.get(i + j).and_then(|s| s.parse::<f64>().ok());
    let (e, t, s) = (n(2)?, n(3)?, n(4)?);
    let mode = args.get(i + 5).cloned().unwrap_or_else(|| "swing".into());
    let rr = if (e - s).abs() > 0.0 { (t - e).abs() / (e - s).abs() } else { 0.0 };
    Some((Plan { up: Some(side == "long"), ote: Some(e), tp_near: Some(t), invalidation: Some(s), rr_near: Some(rr) }, mode))
}

fn today() -> String {
    let secs = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0) as i64;
    let z = secs / 86400 + 719468; let era = z.div_euclid(146097); let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365; let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153; let d = doy - (153 * mp + 2) / 5 + 1; let m = if mp < 10 { mp + 3 } else { mp - 9 };
    format!("{:04}-{:02}-{:02}", yoe + era * 400 + if m <= 2 { 1 } else { 0 }, m, d)
}

fn print_box(b: &GlitchBox, json: bool, verbose: bool) {
    if json { println!("{}", serde_json::to_string_pretty(b).unwrap()); } else { print!("{}", render_text(b, verbose)); }
}

pub fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let json = args.iter().any(|a| a == "--json");
    let verbose = args.iter().any(|a| a == "--verbose");
    let pos: Vec<&String> = { let mut skip = 0usize; let mut v = Vec::new(); for a in &args { if skip > 0 { skip -= 1; continue; } if a == "--plan" { skip = 5; continue; } if !a.starts_with("--") { v.push(a); } } v };
    let end = today();
    match pos.first().map(|s| s.as_str()) {
        Some("demo") => {
            let book = demo_book();
            let plan = Plan { up: Some(true), ote: Some(497.0), tp_near: Some(505.0), invalidation: Some(494.5), rr_near: Some(3.2) };
            let g = glitch_read(&book, Some(&plan)).expect("demo book reads");
            let cards = vec![IndexCard { sym: "VIX".into(), spot: 17.4, king_k: None, error: false }];
            let bars = demo_bars();
            let b = build_box(&book.symbol, g, &bars, Some("2026-09-28"), Some(plan), Some("swing".into()), Some("grew".into()), trinity(&cards, None));
            print_box(&b, json, verbose);
        }
        Some("show") if pos.len() >= 2 => {
            let sym = pos[1].to_uppercase();
            let book = match load_book(&sym) { Ok(b) => b, Err(e) => { eprintln!("{}", e); std::process::exit(2); } };
            let pm = parse_plan(&args);
            let plan = pm.as_ref().map(|x| x.0.clone());
            let Some(g) = glitch_read(&book, plan.as_ref()) else { eprintln!("{}: the book carries no readable map", sym); std::process::exit(1) };
            let mut cards = vec![IndexCard::of(&sym, Some(&g), book.spot, false)];
            for s in ["SPY", "QQQ", "SPXW", "VIX"] { if s != sym { if let Ok(b) = load_book(s) { let gg = glitch_read(&b, None); cards.push(IndexCard::of(s, gg.as_ref(), b.spot, false)); } } }
            let bars = load_daily_bars(&sym, &end);
            let b = build_box(&sym, g, &bars, Some(&end), plan, pm.map(|x| x.1), None, trinity(&cards, None));
            print_box(&b, json, verbose);
        }
        Some("board") if pos.len() >= 2 => {
            let syms: Vec<String> = pos[1..].iter().map(|s| s.to_uppercase()).collect();
            let mut reads: Vec<(String, f64, Option<Glitch>, bool)> = Vec::new();
            for s in &syms { match load_book(s) { Ok(b) => { let g = glitch_read(&b, None); reads.push((s.clone(), b.spot, g, false)); } Err(e) => { eprintln!("{}: {}", s, e); reads.push((s.clone(), 0.0, None, true)); } } }
            let cards: Vec<IndexCard> = reads.iter().map(|(s, sp, g, err)| IndexCard::of(s, g.as_ref(), *sp, *err)).collect();
            let trin = trinity(&cards, None);
            let mut boxes = Vec::new();
            for (s, _, g, _) in reads { if let Some(g) = g { let bars = load_daily_bars(&s, &end); boxes.push(build_box(&s, g, &bars, Some(&end), None, None, None, trin.clone())); } }
            if json { println!("{}", serde_json::to_string_pretty(&boxes).unwrap()); } else { for b in &boxes { print!("{}", render_text(b, verbose)); println!("{}", "─".repeat(100)); } }
        }
        _ => {
            eprintln!("usage: glitch_box demo [--json] [--verbose]\n       glitch_box show SYM [--plan long|short ENTRY TARGET STOP MODE] [--json] [--verbose]\n       glitch_box board SYM… [--json] [--verbose]");
            std::process::exit(2);
        }
    }
}
