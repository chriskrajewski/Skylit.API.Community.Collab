# 👁 Glitch box — GEX/VEX map reader (Rust)

One GEX/VEX book in (strikes × expiries of dealer gamma and vanna), the doctrine's read of it out — as plain text or JSON.

| file | what it is |
| --- | --- |
| `src/glitch_box.rs` | the whole reader and a small CLI, one file |
| `src/base_rates.json` | 1,688 measured base rates the box cites (value · n · 95% CI · a Nov-2025 discovery and a Jan-2026 holdout value); compiled into the binary |
| `Cargo.toml` | deps: `serde`, `serde_json` (with `float_roundtrip`) |

## What it reads

- **Front map** (nearest expiry): King (largest \|γ\|), ceiling and floor (the largest \|γ\| cell on each side of spot — sign does not decide), the gatekeeper between the King and each bound, the air pocket between spot and the next structure, counter-sign landmarks.
- **Full map** (every expiry): King, ceiling and floor as the largest single cell — never a sum across expiries.
- **Node roles**: King · Pika (largest +γ, yellow) · Barney (largest −γ, purple) · Gatekeeper (≥ ¼ of the King).
- **Structures**: rugpull / reverse rugpull, double-stacked ceiling / floor, air pockets, gatekeeper state, King peak / pit.
- **Glitch's own plan**: deflection entry at the floor (long) or ceiling (short), stop one node beyond plus an overshoot margin, target = the gatekeeper on the way to the King, else the King, else the opposite bound.
- **Two theses** written from named nodes, in price order, with no probability words.
- **Wear** (needs daily bars): taps over the last 10 sessions, the session range, fresh / in-play / delivered, and the REACH tag (odds a bound is *touched* next session — never *held*).
- **Regime + Trinity** (SPX / SPY / QQQ bias from each index's full-map King) and **the judge**: the doctrine's five filters run on an outside plan. A checklist, not odds — in training the verdict was inverted (NO PLAY boards paid more than A+ boards).

Display only: nothing here picks a side, sizes a position or vetoes a trade. Base rates are context, never levers.

## Plug points

```rust
pub fn load_book(symbol: &str) -> Result<Book, String>      // your GEX/VEX book: strikes, expiries (nearest first), gamma[i][j], vanna[i][j], spot
pub fn load_daily_bars(symbol: &str, end: &str) -> Vec<Bar> // optional: daily high/low bars, oldest first (empty = wear reads as unread)
```

Pass the whole book; the reader never trims it. Nothing else in the file fetches anything.

## Run

```
cargo build --release
./target/release/glitch_box demo                     # a built-in synthetic book; no plugs needed
./target/release/glitch_box demo --verbose           # + each pill's explanation
./target/release/glitch_box demo --json              # the full read as data
./target/release/glitch_box show SPY --plan long 580 590 576 swing    # judge an outside plan (entry · target · stop · mode)
./target/release/glitch_box board SPY QQQ SPXW VIX AAPL               # Trinity reads SPY / QQQ / SPXW / VIX from the list
```

As a library: `glitch_read(&book, plan)` → `Glitch`; `build_box(...)` adds wear, reach, Trinity, regime and the judge; `render_text(&box, verbose)` prints it.
