// compare.js — INTERNAL. Field-by-field diff of fixtures/glitch.json (the JS outputs) against fixtures/out-rust.json.
// Exact: numbers must be ===, strings byte-equal, keys identical (a JS `undefined` key is absent on both sides).
'use strict';
const fs = require('fs'), path = require('path');
const F = path.join(__dirname, 'fixtures');
const OUTF = path.join(F, 'out-rust.json'), INF = path.join(F, 'glitch.json');
if (!fs.existsSync(OUTF)) { console.log('FAIL: no out-rust.json (the harness crashed or did not run)'); process.exit(1); }
if (fs.statSync(OUTF).mtimeMs < fs.statSync(INF).mtimeMs) { console.log('FAIL: out-rust.json is older than glitch.json — re-run the harness'); process.exit(1); }
const exp = JSON.parse(fs.readFileSync(path.join(F, 'glitch.json'), 'utf8')).cases;
const got = JSON.parse(fs.readFileSync(path.join(F, 'out-rust.json'), 'utf8')).out;
if (exp.length !== got.length) { console.log(`FAIL: ${exp.length} expected cases, ${got.length} outputs`); process.exit(1); }
function diff(a, b, p, out) {
  if (out.length > 6) return;
  if (a === b) return;
  if (typeof a === 'number' && typeof b === 'number') { if (a !== b) out.push(`${p}: js ${a} rust ${b}`); return; }
  if (a === null || b === null || typeof a !== 'object' || typeof b !== 'object') { out.push(`${p}: js ${JSON.stringify(a)} rust ${JSON.stringify(b)}`); return; }
  if (Array.isArray(a) !== Array.isArray(b)) { out.push(`${p}: array vs object`); return; }
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const k of keys) { if (!(k in a)) { out.push(`${p}.${k}: missing in js (rust ${JSON.stringify(b[k])})`); continue; } if (!(k in b)) { out.push(`${p}.${k}: missing in rust (js ${JSON.stringify(a[k])})`); continue; } diff(a[k], b[k], `${p}.${k}`, out); }
}
let bad = 0; const sec = {};
exp.forEach((c, i) => { const o = []; diff(c.expected, got[i], '', o); const s = c.kind; sec[s] = sec[s] || [0, 0]; sec[s][0]++; if (o.length) { sec[s][1]++; if (bad++ < 8) console.log(`case ${i} (${c.kind} ${c.sym}${c.file ? ' ' + path.basename(c.file) + '#' + c.idx : ''}):\n  ` + o.join('\n  ')); } });
for (const [s, [n, m]] of Object.entries(sec)) console.log(`${s.padEnd(5)} ${String(n).padStart(6)} cases · ${m} mismatches`);
console.log(bad ? `FAIL: ${bad} mismatching cases` : 'PASS: 0 mismatches');
process.exit(bad ? 1 : 0);
