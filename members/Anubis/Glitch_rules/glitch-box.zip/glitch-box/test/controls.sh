#!/usr/bin/env bash
# controls.sh — INTERNAL. Each control mutates ONE thing in the Rust port, rebuilds, re-runs the harness and must turn
# compare.js RED. The source is restored from the copy this script makes (trap), then the clean build is re-verified.
set -uo pipefail
cd "$(dirname "$0")/../rust"
SRC=src/glitch_box.rs; BAK=$(mktemp); cp "$SRC" "$BAK"; trap 'cp "$BAK" "$SRC"; rm -f "$BAK"' EXIT
pass=0; fail=0
ctl() { # name · anchor · replacement
  cp "$BAK" "$SRC"
  python3 -c "import sys;p=sys.argv[1];s=open(p).read();a,b=sys.argv[2],sys.argv[3];n=s.count(a)
if n!=1: sys.exit('anchor found %d times' % n)
open(p,'w').write(s.replace(a,b))" "$SRC" "$2" "$3" || { echo "CONTROL BROKEN ($1): anchor"; fail=$((fail+1)); return; }
  cargo build --release -q 2>/dev/null || { echo "CONTROL BROKEN ($1): build"; fail=$((fail+1)); return; }
  ./target/release/glitch_harness ../test/fixtures 2>/dev/null
  if node ../test/compare.js > /tmp/glitch-ctl.$$ 2>&1; then echo "CONTROL DID NOT BITE: $1"; fail=$((fail+1)); else echo "bites: $1 — $(grep -m1 -E '^ +\.' /tmp/glitch-ctl.$$ | sed 's/^ *//' | cut -c1-110)"; pass=$((pass+1)); fi
  rm -f /tmp/glitch-ctl.$$
}
ctl "gatekeeper cut 0.25 → 0.26"      'pub const GK_PCT: f64 = 0.25;' 'pub const GK_PCT: f64 = 0.26;'
ctl "near-node tie rule < → <="       'if b.map_or(true, |x| (c.k - k).abs() < (x.k - k).abs()) { b = Some(c); }' 'if b.map_or(true, |x| (c.k - k).abs() <= (x.k - k).abs()) { b = Some(c); }'
ctl "thesis word first → 1st"         'if k_mid { "next" } else { "first" }, gk_txt)); }
        if k_on' 'if k_mid { "next" } else { "1st" }, gk_txt)); }
        if k_on'
ctl "delivered cut 0.3% → 0.31%"      'pub const DELIVER: f64 = 0.003;' 'pub const DELIVER: f64 = 0.0031;'
ctl "Math.round → f64::round"         'pub fn js_round(x: f64) -> f64 {
    if !x.is_finite() { return x; }' 'pub fn js_round(x: f64) -> f64 {
    if !x.is_finite() || true { return x.round(); }'
ctl "regime TREND range 0.8 → 0.7"    'if al && r >= 0.8 { return "TREND"; }' 'if al && r >= 0.7 { return "TREND"; }'
ctl "reach window 5 → 6 bars"         'let last = &f[f.len().saturating_sub(5)..];' 'let last = &f[f.len().saturating_sub(6)..];'
ctl "judge F2 score 5 → 0"            '(if f2 { 20 } else { 5 })' '(if f2 { 20 } else { 0 })'
ctl "pika keeps 3 → 2 (take(3) shared, so gate the role)" 'for &i in idx.iter().take(3) { used[i] = true; out.push((l[i], role)); }' 'for &i in idx.iter().take(if role == "pika" { 2 } else { 3 }) { used[i] = true; out.push((l[i], role)); }'
cp "$BAK" "$SRC"; cargo build --release -q && ./target/release/glitch_harness ../test/fixtures 2>/dev/null && node ../test/compare.js | tail -1
echo "controls: $pass bite · $fail broken"
[ "$fail" -eq 0 ]
