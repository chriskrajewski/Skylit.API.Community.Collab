// gen_fixtures.js — INTERNAL. Drives the REAL 👁 GLITCH functions, extracted verbatim from the built V15 body
// (gates/sfmaxv15body.js — run `cd gates && node build.js` first), over (a) every raw book in Pure_RAW (the full
// untrimmed grid, as V15 reads it for the box) and (b) a seeded fuzz set of neutral books. Each case also carries a
// synthetic outside plan, daily bars, an end date and a Trinity card list, so wear · reach · trinity · regime · judge ·
// take are all exercised. Writes fixtures/glitch.json; the Rust harness reads the same inputs and compare.js diffs.
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..', '..', '..'), RAW = path.join(ROOT, 'Pure_RAW'), OUT = path.join(__dirname, 'fixtures');
const body = fs.readFileSync(path.join(ROOT, 'gates', 'sfmaxv15body.js'), 'utf8');
const lines = body.split('\n');
const STOP = /^  (async function|function|const|let|var|\/\/|\/\*|[A-Za-z_$][\w$]*\s*[:=(])/;
function extract(kind, name) {
  const start = lines.findIndex((l) => l.startsWith(`  ${kind} ${name}${kind === 'function' ? '(' : ' '}`));
  if (start < 0) throw new Error(`not found in the body: ${kind} ${name}`);
  let end = start + 1; while (end < lines.length && !STOP.test(lines[end])) end++;
  return lines.slice(start, end).join('\n');
}
const FNS = ['px', 'fmtK', 'tapCount', 'mkRead', 'nitroClassify', 'nitroCells', 'accRowsFrom', 'accFullMap', 'glitchOvershoot', 'glitchDoubleStack', 'glitchPlan',
  'glitchThesis', 'glitchOf', 'reachTag', 'reachWear', 'reachOf', 'glitchWear', 'glitchTrinity', 'glitchRegime', 'glitchJudge', 'glitchTake'];
const CONSTS = ['MONKEY_SIG', 'MK_VEX_ABS', 'NITRO', 'GLITCH_SIG', 'REACH_RATIO_CUT', 'REACH_TAGS'];
const src = [...CONSTS.map((c) => extract('const', c)), 'let VIXPIVOT = null; const cards = [];', ...FNS.map((f) => extract('function', f)),
  'return { ' + FNS.join(', ') + ', setPivot: (v) => { VIXPIVOT = v == null ? null : { cur: v }; } };'].join('\n');
const J = new Function(src)();

// seeded PRNG (mulberry32)
let _s = 0x9e3779b9; const rnd = () => { _s |= 0; _s = (_s + 0x6D2B79F5) | 0; let t = Math.imul(_s ^ (_s >>> 15), 1 | _s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const r4 = (x) => Math.round(x * 1e4) / 1e4;

function synthPlan(M, spot, rows) {
  const u = rnd(); if (u < 0.2) return null;
  const mid = () => { if (rows.length < 2) return null; const i = Math.floor(rnd() * (rows.length - 1)); return (rows[i].strike + rows[i + 1].strike) / 2; }; // exact midpoints: the near-node tie rule
  const up = rnd() < 0.5, near = (b, f) => (b ? b.k : spot * f);
  const ote = u < 0.25 ? null : up ? (rnd() < 0.6 ? near(M.floor, 0.99) : r4(spot * (1 - rnd() * 0.02))) : (rnd() < 0.6 ? near(M.ceiling, 1.01) : r4(spot * (1 + rnd() * 0.02)));
  const tp = rnd() < 0.08 ? null : up ? (rnd() < 0.6 ? near(M.ceiling, 1.02) : r4(spot * (1 + rnd() * 0.04))) : (rnd() < 0.6 ? near(M.floor, 0.98) : r4(spot * (1 - rnd() * 0.04)));
  const inv = rnd() < 0.08 ? null : ote == null ? r4(spot * 0.97) : r4(ote * (up ? 1 - rnd() * 0.015 : 1 + rnd() * 0.015));
  const rr = rnd() < 0.1 ? null : (ote != null && tp != null && inv != null && ote !== inv) ? Math.abs(tp - ote) / Math.abs(ote - inv) : rnd() * 6;
  const P = { up, ote, tpNear: tp, invalidation: inv, rrNear: rr };
  if (rnd() < 0.15) { const m = mid(); if (m != null) P.tpNear = m; } if (rnd() < 0.15) { const m = mid(); if (m != null) P.invalidation = m; }
  return P;
}
function synthBars(spot, M, plan) {
  const n = Math.floor(rnd() * 16); if (!n) return null; const bars = [];
  const anchors = [M.floor && M.floor.k, M.ceiling && M.ceiling.k, plan && plan.ote, plan && plan.tpNear, plan && plan.invalidation].filter((x) => x != null);
  for (let i = 0; i < n; i++) {
    const c = anchors.length && rnd() < 0.4 ? pick(anchors) * (1 + (rnd() - 0.5) * 0.004) : spot * (1 + (rnd() - 0.5) * 0.03);
    const w = spot * rnd() * 0.012; const zero = rnd() < 0.03;
    bars.push({ d: `2026-08-${String(i + 1).padStart(2, '0')}`, h: zero ? 0 : r4(c + w), l: zero ? 0 : r4(c - w * rnd()) });
  }
  return bars;
}
function synthTrin() {
  const L = []; const n = Math.floor(rnd() * 6);
  for (let i = 0; i < n; i++) {
    const sym = pick(['SPY', 'QQQ', 'SPXW', 'VIX', 'AAPL', 'SPY']); const spot = sym === 'VIX' ? (rnd() < 0.1 ? 0 : r4(12 + rnd() * 25)) : r4(100 + rnd() * 600);
    const kingK = rnd() < 0.1 ? null : r4(spot * (1 + pick([-0.01, -0.0005, 0, 0.0005, 0.01, 0.02, -0.02]))); const error = rnd() < 0.1;
    L.push({ sym, spot, kingK, error });
  }
  if (rnd() < 0.25) { const dir = rnd() < 0.5 ? 1 : -1; for (const s of ['SPY', 'QQQ', 'SPXW']) { const spot = r4(100 + rnd() * 600); L.unshift({ sym: s, spot, kingK: r4(spot * (1 + dir * 0.01)), error: false }); } }
  return L;
}
const asCards = (L) => L.map((c) => ({ sym: c.sym, spot: c.spot, error: c.error || undefined, glitch: c.kingK == null ? null : { full: { king: { k: c.kingK } } } }));

function runCase(d, sym, ref) {
  const gf = J.accRowsFrom(d); const M = J.mkRead(gf.rows, gf.spot, gf.exps);
  const spot = gf.spot; const plan = M ? synthPlan(M, spot, gf.rows) : null; const bars = M ? synthBars(spot, M, plan) : null;
  const endD = bars ? pick([null, bars[bars.length - 1].d, bars[Math.floor(bars.length / 2)].d, '2026-07-01', '']) : null;
  const trinIn = synthTrin(); const vixPivot = rnd() < 0.5 ? null : r4(10 + rnd() * 25);
  const G = M ? J.glitchOf(M, gf.rows, gf.exps, spot, sym, plan) : null;
  let reach = null;
  if (G && bars) { J.glitchWear(G, bars, spot, endD, plan); reach = J.reachOf(G, bars, endD) || null; }
  J.setPivot(vixPivot); const cards = asCards(trinIn); const trin = J.glitchTrinity(cards);
  const regime = J.glitchRegime(trin, G && G.wear ? G.wear.range : null);
  const c = { side: plan, glitch: G, mode: 'swing' };
  const judge = J.glitchJudge(c, G, trin, regime); const take = J.glitchTake(c, cards);
  return { ...ref, sym, plan, bars, endD, trinIn, vixPivot, expected: JSON.parse(JSON.stringify({ G: G || null, reach, trin, regime, judge, take: take || null })) };
}

const cases = [];
// (a) every raw book on disk
const t0 = Date.now(); let nRaw = 0;
const MAXR = +(process.env.GLITCH_MAX_RAW || Infinity);
for (const f of fs.readdirSync(RAW).filter((x) => x.startsWith('sfa-backtest-') && x.endsWith('.json')).sort()) {
  let j = JSON.parse(fs.readFileSync(path.join(RAW, f), 'utf8')); const sym = j.ticker;
  j.snapshots.forEach((s, idx) => { if (nRaw >= MAXR || !s.ok || !s.data || !Array.isArray(s.data.Strikes) || !s.data.Strikes.length) return; cases.push(runCase(s.data, sym, { kind: 'raw', file: path.relative(__dirname, path.join(RAW, f)), idx })); nRaw++; });
  j = null; process.stdout.write(`\r raw ${nRaw} books · ${((Date.now() - t0) / 1000).toFixed(0)} s   `);
}
console.log();
// (b) fuzz: neutral books, index and stock symbols, edge shapes
for (let i = 0; i < 1500; i++) {
  const sym = pick(['SPY', 'QQQ', 'SPXW', 'SPX', 'NDX', 'AAPL', 'TSLA', 'IWM', 'XYZ']);
  const spot = r4(sym.startsWith('SPX') || sym === 'NDX' ? 4000 + rnd() * 18000 : 5 + rnd() * 900);
  const nK = pick([1, 2, 3, 5, 12, 30, 60, 120]), nE = pick([1, 1, 2, 3, 7, 12]);
  const step = pick([0.5, 1, 2.5, 5, 10, 25]) * (spot > 2000 ? 5 : spot < 30 ? 0.1 : 1);
  const lo = spot - step * Math.floor(nK * (rnd() < 0.15 ? 1.2 : rnd() < 0.15 ? -0.2 : 0.5));
  const strikes = [], gamma = [], vanna = [];
  for (let s = 0; s < nK; s++) {
    strikes.push(+(lo + s * step).toFixed(2)); const ga = [], va = [];
    for (let e = 0; e < nE; e++) { const z = rnd(); ga.push(z < 0.25 ? 0 : z < 0.3 ? null : z < 0.4 ? Math.round((rnd() - 0.6) * 1e6) + 0.5 /* exact .5: Math.round ties */ : Math.round((rnd() - pick([0.5, 0.2, 0.8])) * 10 ** (3 + Math.floor(rnd() * 6)))); va.push(rnd() < 0.3 ? 0 : Math.round((rnd() - 0.5) * 10 ** (3 + Math.floor(rnd() * 5)))); }
    gamma.push(ga); vanna.push(va);
  }
  if (rnd() < 0.1 && nK > 3) { const a = Math.floor(rnd() * nK), b = Math.floor(rnd() * nK); gamma[b][0] = gamma[a][0]; } // exact ties
  if (rnd() < 0.05) { strikes.reverse(); }
  const expiries = Array.from({ length: nE }, (_, e) => `2026-${String(9 + Math.floor(e / 4)).padStart(2, '0')}-${String(1 + (e % 4) * 7).padStart(2, '0')}`);
  const d = { Strikes: strikes, GammaValues: gamma, VannaValues: vanna, Expirations: expiries, CurrentSpot: rnd() < 0.02 ? 0 : spot };
  const book = { symbol: sym, spot: d.CurrentSpot, expiries, strikes, gamma: gamma.map((r) => r.map((x) => x == null ? 0 : x)), vanna };
  cases.push(runCase(d, sym, { kind: 'fuzz', book }));
}
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'glitch.json'), JSON.stringify({ cases }));
const cov = {}; const bump = (k) => { cov[k] = (cov[k] || 0) + 1; };
for (const c of cases) { const e = c.expected; if (!e.G) { bump('noread'); continue; } bump('read'); const P = e.G.patterns; for (const k of ['rugpull', 'reverseRugpull', 'pocketUp', 'pocketDn', 'dsCeil', 'dsFloor']) if (P[k]) bump(k); if (e.G.wear) bump('wear'); if (e.reach) bump('reach'); bump('regime:' + e.regime); bump('verdict:' + e.judge.verdict); if (e.trin.aligned) bump('trin3'); bump('gkC:' + e.G.front.gkC.state); bump('pkUp:' + e.G.front.pkUp.state); }
console.log('cases', cases.length, '(raw', nRaw + ')', JSON.stringify(cov));
