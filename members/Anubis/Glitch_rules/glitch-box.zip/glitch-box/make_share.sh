#!/usr/bin/env bash
# make_share.sh — INTERNAL. Snapshots the shareable Glitch box files into port/share/glitch-box/, refuses on any leaked
# token (data source, desk names, internal paths, corpora, internal function names), proves the copy builds and runs
# from a directory holding nothing else, and lists what to hand over. Share ONLY what lands in port/share/glitch-box/.
set -euo pipefail
cd "$(dirname "$0")"
OUT=../share/glitch-box
rm -rf "$OUT"; mkdir -p "$OUT/src"
cp rust/Cargo.toml          "$OUT/Cargo.toml"
cp rust/src/glitch_box.rs   "$OUT/src/glitch_box.rs"
cp rust/src/base_rates.json "$OUT/src/base_rates.json"
cp SHARE-README.md          "$OUT/README.md"

# ── the leak audit ──
CI='skylit|sfmax|sirfartalot|fartalot|monkey|nitro|heatseeker|atlas|agent_zero|pure_raw|studies|study_|/api|nexus|alpaca|clerk|bearer|telegram|discord|qwen|tampermonkey|userscript|greasemonkey|backtest|fixture|harness|_accfull|mkread|accfullmap|accrowsfrom|glitch_params|glitch_cal|v1[0-9]\b|\bsfa\b|"src":"db"|app\.|\.ai\b|https?://'
CS='CurrentSpot|GammaValues|VannaValues|Expirations|"Strikes"|PriceChange|PreviousClose|ReplayMode|HistoricalTimestamp'
fail=0
for f in "$OUT/Cargo.toml" "$OUT/src/glitch_box.rs" "$OUT/src/base_rates.json" "$OUT/README.md"; do
  if grep -n -i -E "$CI" "$f" | cut -c1-160; then echo "LEAK: $f (above)"; fail=1; fi
  if grep -n -E "$CS" "$f" | cut -c1-160; then echo "LEAK: $f carries a wire field name (above)"; fail=1; fi
done
[ "$fail" -eq 0 ] || { rm -rf "$OUT"; echo "share/glitch-box NOT valid — fix the source, never the audit"; exit 1; }
echo "leak audit: clean"

# ── isolation build ──
T="$(mktemp -d)/glitch-share-$$"; mkdir -p "$T"; cp -R "$OUT"/. "$T"/
( cd "$T" && cargo build --release -q 2>&1 | tail -5
  ./target/release/glitch_box demo | grep -q 'GLITCH READS THE MAP' && ./target/release/glitch_box demo --json | grep -q '"verdict"'
  msg=$(./target/release/glitch_box show SPY 2>&1 || true); printf '%s' "$msg" | grep -q 'load_book is not wired' && echo "builds alone, demo runs, show reports the unplugged book" )
rm -rf "$T"
echo; echo "share these, and only these:"; ( cd "$OUT" && find . -type f | sort | while read -r f; do printf '  %-24s %8s bytes  md5 %s\n' "${f#./}" "$(wc -c < "$f" | tr -d ' ')" "$(md5 -q "$f")"; done )
